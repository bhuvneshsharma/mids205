---
title: "Assignment 07 for W205 by Bhuvnesh Sharma"
author: "Bhuvnesh Sharma"
---



#  Assignment 7 from Bhuvnesh Sharma for W205

## Executive Summary

In the age of cloud computing , we are exploring new architectures of managed services architectures. Infrastructure container services like docker have containerized the application architectures. 
We are also exploring different architectures including Lambda architecture , where there is 
- Batch Layer
- Speed layer
- Serving layer 
This data services can we real time data publish subscribe services based on KAFKA. The application gets data from student trying an exam and question attempts. This data can be real time feed into fast , scalable , durable and fault tolerant messaging system. This model can be used to create multiple applications.

With Spark we can make the processing of data frames extremely parallel computation process

Conceptual Diagram : 
![ALT TEXT](https://databricks.com/wp-content/uploads/2017/04/structured-streaming-kafka-blog-image-1-overview.png)



In this assignment we integrated kafka and spark . We would explore in future assignment integrating the following high level architecture picture.

![ALT TEXT](https://www.tutorialspoint.com/apache_kafka/images/integration_spark.jpg)


## Approach

We would be following approach

- Login to the droplet using the credentials provided.
- Connect to git and clone the repo assignment-07-bhuvneshsharma.
- cd to the directory  assignment 07.
- Download the json file using curl
- Configure docker-compose yml file
- explain the YML and different pieces of architecture.
	- kafka
	- spark
	- zookeeper
	- mids 
- Begin docker
- Create kafka topic
- Publish JSON messages.
- Explore PYSPARK to subscribe and read messages
- Import JSON
- Explore python by reading messages and parsing it.
- Shutdown the docker.

   We are planning to login to the machine where my student droplet has been configured. From that droplet machine we will spin up a cluster with spark,kafka, zookeeper, and the mids container within Docker.
Create a cluster which can map in directory structure virtually and also have the cluster talk to each other.
   Explore the different configurations of the the docker , kafka ,  zookeeper and mids. Then our goal is to stream messages to topics on kafka and then have those message topics be read via spark and pyspark.

### Login to the droplet

Using the account provided by MIDS program login to the droplet

#### Check the directory

```
pwd

cd w205

pwd

```

The result should be as below

```
/home/science/
/home/science/w205
```

### Clone the repository from github

Connect to github using git utility and clone the assignment 07

```
git clone https://github.com/mids-w205-crook/assignment-07-bhuvneshsharma.git

```

####  Move in the directory for the assignment


```
cd /home/science/w205/assignment-07-bhuvneshsharma

```

#### List down all the contents of the directory using following command

```
ls -lrt

```

#### Get the data from the location given the json file using the curl command.

Download the data file from the prescribed location. The json file once downloaded we need to explore the file.

The options -L for curl is to get the file from the location defined by the http location.
-o option downloads the file with file name instead of putting in stdout.


```
curl -L -o assessment-attempts-20180128-121051-nested.json https://goo.gl/f5bRm4

```

#### List down the files in directory again
To confirm that file assessment-attempts-20180128-121051-nested.json has been downloaded from the location https://goo.gl/f5bRm4 run the following command.


```
ls -lrt
```
We see the following output , which confirms that the file is downloaded correctly.

```
-rw-rw-r-- 1 science science 9315053 Jul  1 23:23 assessment-attempts-20180128-121051-nested.json
```

#### Explore the JSON file

We would explore the JSON file to better understand the data file.

```
cat /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
more /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
tail -f /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
head -10  /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json

```

JSON file appears to be machine readable file and hence it does not have spaces. We would have to use other tools to better explore the file.
We will be using jq command line utility to better understand the JSON.


```
cat /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq .
cat /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq  '.[0]'
cat /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort
cat /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr
cat /home/science/w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr | head -10

```

jq is command line tool that helps to better understand the json output from machine readable to human readable. Machine readable JSON output is typically created by web applications and hence to save size of packets all spaces are removed.

Output of the one of the command should be similar to the output below

```
        {
          "user_incomplete": false,
          "user_correct": true,
          "options": [
            {
              "checked": true,
              "at": "2017-11-29T06:24:32.426Z",
              "id": "00f18c5b-40f6-483e-b60d-1d1eda18ea13",
              "submitted": 1,
              "correct": true
            },
            {
              "checked": false,
              "id": "a8b278fc-74e2-4d5d-9a50-4158a8b34eff"
            },
```

## create a docker yml file

Move the assignment directory and make the docker-compose.yml file.

```
cd /home/science/w205/assignment-07-bhuvneshsharma

vi docker-compose.yml
```

Insert the following code to the YML file and save it.

```
---
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"
    extra_hosts:
      - "moby:127.0.0.1"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    volumes:
      - ~/w205:/w205
    expose:
      - "9092"
      - "29092"
    extra_hosts:
      - "moby:127.0.0.1"

  spark:
    image: midsw205/spark-python:0.0.5
    stdin_open: true
    tty: true
    volumes:
      - ~/w205:/w205
    command: bash
    extra_hosts:
      - "moby:127.0.0.1"

  mids:
    image: midsw205/base:latest
    stdin_open: true
    tty: true
    volumes:
      - ~/w205:/w205
    extra_hosts:
      - "moby:127.0.0.1"

```

## Understanding docker-compose.yml

The docker-compose.yml is configuring 4 different containers within the cluster. The containers in the cluster are the following
- zookeeper
- kafka
- spark
- mids

###  zookeeper
ZooKeeper is a centralized service for maintaining configuration information, naming, providing distributed synchronization, and providing group services.
Zookeeper is distributed systems configuration management tool. Zookeeper provides multiple features for distributed applications like distributed configuration management, leader election, consensus handling, coordination and locks etc.Zookeeper storing its data on tree like structure. It introduced as Data Tree and nodes introduced as zNodes. Zookeeper follows standard unix notations for file paths.

##### image: confluentinc/cp-zookeeper:latest 
        
This is from where we need to get the configuration of zookeeper. Also the setting is specifing that we need to get the latest configuration.
If configured as following confluentinc/cp-zookeeper:4.0.0 , then it is pointing to use the version 4.0.0

##### ZOOKEEPER_CLIENT_PORT
ZOOKEEPER_CLIENT_PORT: 32181
ZOOKEEPER_TICK_TIME: 2000

ZOOKEEPER_CLIENT_PORT is the port on which we are configuring zookeeper , port configured is 32181. ZooKeeper where to listen for connections by clien          ts such as Kafka

##### expose
 These are the ports which are opened


###  kafka
Kafka is Fast, Scalable, Durable, and Fault-Tolerant publish-subscribe messaging system which can be used to real time data streaming. We can introduce Kafka as Distributed Commit Log which follows publish subscribe architecture. Like many publish-subscribe messaging systems, Kafka maintains feeds of messages in topics. Producers write data to topics and consumers read from topics. Since Kafka is a distributed system, topics are partitioned and replicated across multiple nodes.
Messages in Kafka are simple byte arrays(String , JSON etc). When publishing, message can be attached to a key. Producer distributes all the messages with same key into same partition.

Kafka uses Zookeeper to mange following tasks
- Electing a controller - The controller is one of the brokers and is responsible for maintaining the leader/follower relationship for all the partitions. When a node shuts down, it is the controller that tells other replicas to become partition leaders to replace the partition leaders on the node that is going away. Zookeeper is used to elect a controller, make sure there is only one and elect a new one it if it crashes.
- Cluster membership - Which brokers are alive and part of the cluster? this is also managed through ZooKeeper.
- Topic configuration - Which topics exist, how many partitions each has, where are the replicas, who is the preferred leader, what configuration overrides are set for each topic
- Manage Quotas - How much data is each client allowed to read and write
- Access control - Who is allowed to read and write to which topic (old high level consumer). Which consumer groups exist, who are their members and what is the latest offset each group got from each partition


##### image: confluentinc/cp-kafka:latest
This is from where we need to get the configuration of kafka. Also the setting is specifing that we need to get the latest configuration.If configured as following confluentinc/cp-kafka:4.0.0 , then it is pointing to use the version 4.0.0

##### depends_on
This configuration requests points to that the fact that this container of kafka depends on zookeeper container.

##### KAFKA_ZOOKEEPER_CONNECT
Connects to zookeeper container at port 32181
##### KAFKA_ADVERTISED_LISTENERS 
Advertised listeners is required for starting up the Docker image because it is important to think through how other clients are going to connect to kafka. In a Docker environment, you will need to make sure that your clients can connect to Kafka and other services. Advertised listeners is how it gives out a host name that can be reached by the client.
KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092

##### KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR
 This is needed when you are running with a single-node cluster. If you have three or more nodes, you do not need to change this from the default. Current setting is 1.

#####    volumes:
Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

#####    expose:
        These are the ports which are exposed.
         - "9092"
         - "29092"
#####   extra_hosts:
        This is moby network which is getting mapped to 127.0.0.1
        - "moby:127.0.0.1"

### 3) spark

Spark is a fast and general cluster computing system for Big Data. It provides high-level APIs in Scala, Java, Python, and R, and an optimized engine that supports general computation graphs for data analysis. It also supports a rich set of higher-level tools including Spark SQL for SQL and DataFrames, MLlib for machine learning, GraphX for graph processing, and Spark Streaming for stream processing.

Spark Streaming API enables scalable, high-throughput, fault-tolerant stream processing of live data streams. Data can be ingested from many sources like Kafka, Flume, Twitter, etc., and can be processed using complex algorithms such as high-level functions like map, reduce, join and window. Finally, processed data can be pushed out to filesystems, databases, and live dash-boards. Resilient Distributed Datasets (RDD) is a fundamental data structure of Spark. It is an immutable distributed collection of objects. Each dataset in RDD is divided into logical partitions, which may be computed on different nodes of the cluster.


#####     image: midsw205/spark-python:0.0.5
 This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the spark-python:0.0.5 configuration.
#####    volumes:
Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.
#####    command
The default Shell that needs to be open as first command
#####   extra_hosts:
 This is moby network which is getting mapped to 127.0.0.1
 - "moby:127.0.0.1"
#####    stdin_open
#####    tty
A tty is essentially a text input output environment aka shell.

### 4) mids

#####     image: midsw205/base:latest
This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the latest configuration.
#####   extra_hosts:
This is moby network which is getting mapped to 127.0.0.1
#####    volumes:
        Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

## Docker

Bring up the docker cluster. The -d option tells us to detach the cluster from the current terminal - essentiall it will run "headless".
It is important to run the command from the directory where docker-compose.yml. If we are in a directory without a docker-compose.yml file, docker-compose will throw an error.

```
docker-compose up -d
```
Following output should be on the screen .

```
		Creating network "assignment07bhuvneshsharma_default" with the default driver
		Creating assignment07bhuvneshsharma_spark_1
		Creating assignment07bhuvneshsharma_zookeeper_1
		Creating assignment07bhuvneshsharma_mids_1
		Creating assignment07bhuvneshsharma_kafka_1
```


If you want to see the kafka logs live as it comes up use the following command. The -f tells it to keep checking the file for any new additions to the file and print them. To stop this command, use a control-C:

```
docker-compose logs -f kafka
```

        Following output is what we should  see

```
		kafka_1      | [2018-07-01 23:46:19,211] INFO [SocketServer brokerId=1] Started 1 acceptor threads (kafka.network.SocketServer)
		kafka_1      | [2018-07-01 23:46:19,448] INFO [ReplicaStateMachine controllerId=1] Started replica state machine with initial state -> Map() (kafka.controller.ReplicaStateMachine)
		kafka_1      | [2018-07-01 23:46:19,457] INFO [PartitionStateMachine controllerId=1] Started partition state machine with initial state -> Map() (kafka.controller.PartitionStateMachine)
		kafka_1      | [2018-07-01 23:46:19,506] INFO [SocketServer brokerId=1] Started processors for 1 acceptors (kafka.network.SocketServer)
		kafka_1      | [2018-07-01 23:46:19,510] INFO [KafkaServer id=1] started (kafka.server.KafkaServer)
```

Check and see if our cluster is running. This checks if the docker processes are up and running.

```
docker-compose ps
```

        Following output is what we should  see

```
                 Name                             Command            State                    Ports                  
--------------------------------------------------------------------------------------------------------------------
assignment07bhuvneshsharma_kafka_1       /etc/confluent/docker/run   Up      29092/tcp, 9092/tcp                     
assignment07bhuvneshsharma_mids_1        /bin/bash                   Up      8888/tcp                                
assignment07bhuvneshsharma_spark_1       docker-entrypoint.sh bash   Up                                              
assignment07bhuvneshsharma_zookeeper_1   /etc/confluent/docker/run   Up      2181/tcp, 2888/tcp, 32181/tcp, 3888/tcp 
```

```
docker ps -a

```
You should see the following message to let us know the topic assessment was created correctly:

```
CONTAINER ID        IMAGE                              COMMAND                  CREATED             STATUS                    PORTS                                     NAMES
0c46dd7d7c1a        confluentinc/cp-kafka:latest       "/etc/confluent/dock…"   5 minutes ago       Up 5 minutes              9092/tcp, 29092/tcp                       assignment07bhuvneshsharma_kafka_1
0852ba15af7c        midsw205/base:latest               "/bin/bash"              6 minutes ago       Up 5 minutes              8888/tcp                                  assignment07bhuvneshsharma_mids_1
f3248c92090a        confluentinc/cp-zookeeper:latest   "/etc/confluent/dock…"   6 minutes ago       Up 5 minutes              2181/tcp, 2888/tcp, 3888/tcp, 32181/tcp   assignment07bhuvneshsharma_zookeeper_1
ac40c36e3d5a        midsw205/spark-python:0.0.5        "docker-entrypoint.s…"   6 minutes ago       Up 5 minutes                                                        assignment07bhuvneshsharma_spark_1
```

## Create a topic
Create a topic called assessment in the kafka container using the kafka-topics utility with the following command.

```
                docker-compose exec kafka \
                         kafka-topics \
                         --create \
                        --topic assessment \
                        --partitions 1 \
                        --replication-factor 1 \
                        --if-not-exists \
                        --zookeeper zookeeper:32181
```
	
	Same command in 1 line which creates "assessment" topic

```
docker-compose exec kafka kafka-topics --create --topic assessment --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```

You should see the following message to let us know the topic assessment was created correctly:

```
		Created topic "assessment".
```

Check the topic in the kafka container using the kafka-topics utility:

```
		docker-compose exec kafka \
			  kafka-topics \
			  --describe \
			  --topic assessment \
			  --zookeeper zookeeper:32181
```

Single line command is as follows

```
docker-compose exec kafka kafka-topics --describe --topic assessment --zookeeper zookeeper:32181
```

You should see the following message

```
		Topic:assessment	PartitionCount:1	ReplicationFactor:1	Configs:
		Topic: assessment	Partition: 0	Leader: 1	Replicas: 1	Isr: 1
```

## Use this docker-compose exec command:

This is a microservice which is using kafcat utility to read the json file , Next we are going to use jq utility as well. We are using jq utility to parse the JSON file and send messages to the "assessment" topic.
```
docker-compose exec mids bash -c "cat /w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json"
docker-compose exec mids bash -c "cat /w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.'"
docker-compose exec mids bash -c "cat /w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assessment && echo 'Produced  messages.'"
```

This command allows us to login into mids container into a bash shell and then run the command

```
cat /home/science /w205/assignment-07-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assessment && echo 'Produced 100 messages.'
```

Following output should there
```
Produced  messages.
```

### kafcat
kafkacat is a command line utility that you can use to test and debug Apache Kafka deployments. You can use kafkacat to produce, consume, and list topic and partition information for Kafka. Described as “netcat for Kafka”, it is a swiss-army knife of tools for inspecting and creating data in Kafka.

### PYSPARK

In the spark container, run the python spark command line utility called pyspark.The Spark Python API (PySpark) exposes the Spark programming model to Python.

```
docker-compose exec spark pyspark
```


You should see the following output , Pyspark is the which we are going to use to subscribe to the messages topic which has been shared in the kafka queues

```
Type "help", "copyright", "credits" or "license" for more information.
Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel). For SparkR, use setLogLevel(newLevel).
18/07/02 02:56:42 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
18/07/02 02:56:49 WARN ObjectStore: Version information not found in metastore. hive.metastore.schema.verification is not enabled so recording the schema version 1.2.0
18/07/02 02:56:49 WARN ObjectStore: Failed to get database default, returning NoSuchObjectException
18/07/02 02:56:50 WARN ObjectStore: Failed to get database global_temp, returning NoSuchObjectException
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /__ / .__/\_,_/_/ /_/\_\   version 2.2.0
      /_/

Using Python version 3.6.1 (default, May 11 2017 13:09:58)
SparkSession available as 'spark'.
>>> 
```

assessment_details is thespark data frame which is built on top of a spark RDD, using python code we are going read the topic assessment from the kafka queue @ port 29092. Current configuration is reading the messages from the start and ending at the latest messages.

```
		assessment_details = spark \
			.read \
  			.format("kafka") \
 			.option("kafka.bootstrap.servers", "kafka:29092") \
  			.option("subscribe","assessment") \
  			.option("startingOffsets", "earliest") \
  			.option("endingOffsets", "latest") \
  			.load() 
```

The same command in 1 single line , we are reading the message topic from the kafka queue. The output of this from would be a data frame and we would parse the data frame to analyze the results.
```
assessment_details = spark.read.format("kafka").option("kafka.bootstrap.servers", "kafka:29092").option("subscribe","assessment").option("startingOffsets", "earliest").option("endingOffsets", "latest").load() 
```

Now lets print the schema for the data frame assessment_details
Print the schema for the data frame. Note that the values are shown in binary, which we cant read.

```
assessment_details.printSchema()
```

	Following output @ pyspark

```
>>> assessment_details.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)

```
 This is RDD data frame . Resilient Distributed Datasets (RDD) is a fundamental data structure of Spark. It is an immutable distributed collection of objects. Each dataset in RDD is divided into logical partitions, which may be computed on different nodes of the cluster. RDDs can contain any type of Python, Java, or Scala objects, including user-defined classes.

Since we have a hard time reading binary for the value, let's translate the key and value into strings so we can read them. Create a new data frame which stores the numbers as strings. Since data frames are immutable, so we cannot change them in place, we have to make a copy:

```
assessment_details_string=assessment_details.selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")

```

Display the entire data frame. Note that now we can read the key and value:

```
assessment_details_string.show()
```

Show function 

```
+----+--------------------+
| key|               value|
+----+--------------------+
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
|null|{"keen_timestamp"...|
+----+--------------------+
only showing top 20 rows
```

Display the schema for the data frame assessment_details_string using following command and the result is also presented

```
assessment_details_string.printSchema()
```
	
```
root
 |-- key: string (nullable = true)
 |-- value: string (nullable = true)
```

Lets find the size of the data frame using the count command.

```
assessment_details_string.count()
```

```
		3280
```


We can use python to access individual record within the JSON . In this case are getting 1 record from JSON and we are not using extremely large parallel processing.

```
assessment_details_string.select('value').take(1)
assessment_details_string.select('value').take(1)[0].value
```

Following output is observed 

```
[Row(value='{"keen_timestamp":"1516717442.735266","max_attempts":"1.0","started_at":"2018-01-23T14:23:19.082Z","base_exam_id":"37f0a30a-7464-11e6-aa92-a8667f27e5dc","user_exam_id":"6d4089e4-bde5-4a22-b65f-18bce9ab79c8","sequences":{"questions":[{"user_incomplete":true,"user_correct":false,"options":[{"checked":true,"at":"2018-01-23T14:23:24.670Z","id":"49c574b4-5c82-4ffd-9bd1-c3358faf850d","submitted":1,"correct":true},{"checked":true,"at":"2018-01-23T14:23:25.914Z","id":"f2528210-35c3-4320-acf3-9056567ea19f","submitted":1,"correct":true},{"checked":false,"correct":true,"id":"d1bf026f-554f-4543-bdd2-54dcf105b826"}],"user_submitted":true,"id":"7a2ed6d3-f492-49b3-b8aa-d080a8aad986","user_result":"missed_some"},{"user_incomplete":false,"user_correct":false,"options":[{"checked":true,"at":"2018-01-23T14:23:30.116Z","id":"a35d0e80-8c49-415d-b8cb-c21a02627e2b","submitted":1},{"checked":false,"correct":true,"id":"bccd6e2e-2cef-4c72-8bfa-317db0ac48bb"},{"checked":true,"at":"2018-01-23T14:23:41.791Z","id":"7e0b639a-2ef8-4604-b7eb-5018bd81a91b","submitted":1,"correct":true}],"user_submitted":true,"id":"bbed4358-999d-4462-9596-bad5173a6ecb","user_result":"incorrect"},{"user_incomplete":false,"user_correct":true,"options":[{"checked":false,"at":"2018-01-23T14:23:52.510Z","id":"a9333679-de9d-41ff-bb3d-b239d6b95732"},{"checked":false,"id":"85795acc-b4b1-4510-bd6e-41648a3553c9"},{"checked":true,"at":"2018-01-23T14:23:54.223Z","id":"c185ecdb-48fb-4edb-ae4e-0204ac7a0909","submitted":1,"correct":true},{"checked":true,"at":"2018-01-23T14:23:53.862Z","id":"77a66c83-d001-45cd-9a5a-6bba8eb7389e","submitted":1,"correct":true}],"user_submitted":true,"id":"e6ad8644-96b1-4617-b37b-a263dded202c","user_result":"correct"},{"user_incomplete":false,"user_correct":true,"options":[{"checked":false,"id":"59b9fc4b-f239-4850-b1f9-912d1fd3ca13"},{"checked":false,"id":"2c29e8e8-d4a8-406e-9cdf-de28ec5890fe"},{"checked":false,"id":"62feee6e-9b76-4123-bd9e-c0b35126b1f1"},{"checked":true,"at":"2018-01-23T14:24:00.807Z","id":"7f13df9c-fcbe-4424-914f-2206f106765c","submitted":1,"correct":true}],"user_submitted":true,"id":"95194331-ac43-454e-83de-ea8913067055","user_result":"correct"}],"attempt":1,"id":"5b28a462-7a3b-42e0-b508-09f3906d1703","counts":{"incomplete":1,"submitted":4,"incorrect":1,"all_correct":false,"correct":2,"total":4,"unanswered":0}},"keen_created_at":"1516717442.735266","certification":"false","keen_id":"5a6745820eb8ab00016be1f1","exam_name":"Normal Forms and All That Jazz Master Class"}')]

```

Processing to get individual fields


```
import json
first_message=json.loads(assessment_details_string.select('value').take(1)[0].value)
first_message
print(first_message['exam_name'])
print(first_message['max_attempts'])
print(first_message['user_exam_id'])
```

```
{'keen_timestamp': '1516717442.735266', 'max_attempts': '1.0', 'started_at': '2018-01-23T14:23:19.082Z', 'base_exam_id': '37f0a30a-7464-11e6-aa92-a8667f27e5dc', 'user_exam_id': '6d4089e4-bde5-4a22-b65f-18bce9ab79c8', 'sequences': {'questions': [{'user_incomplete': True, 'user_correct': False, 'options': [{'checked': True, 'at': '2018-01-23T14:23:24.670Z', 'id': '49c574b4-5c82-4ffd-9bd1-c3358faf850d', 'submitted': 1, 'correct': True}, {'checked': True, 'at': '2018-01-23T14:23:25.914Z', 'id': 'f2528210-35c3-4320-acf3-9056567ea19f', 'submitted': 1, 'correct': True}, {'checked': False, 'correct': True, 'id': 'd1bf026f-554f-4543-bdd2-54dcf105b826'}], 'user_submitted': True, 'id': '7a2ed6d3-f492-49b3-b8aa-d080a8aad986', 'user_result': 'missed_some'}, {'user_incomplete': False, 'user_correct': False, 'options': [{'checked': True, 'at': '2018-01-23T14:23:30.116Z', 'id': 'a35d0e80-8c49-415d-b8cb-c21a02627e2b', 'submitted': 1}, {'checked': False, 'correct': True, 'id': 'bccd6e2e-2cef-4c72-8bfa-317db0ac48bb'}, {'checked': True, 'at': '2018-01-23T14:23:41.791Z', 'id': '7e0b639a-2ef8-4604-b7eb-5018bd81a91b', 'submitted': 1, 'correct': True}], 'user_submitted': True, 'id': 'bbed4358-999d-4462-9596-bad5173a6ecb', 'user_result': 'incorrect'}, {'user_incomplete': False, 'user_correct': True, 'options': [{'checked': False, 'at': '2018-01-23T14:23:52.510Z', 'id': 'a9333679-de9d-41ff-bb3d-b239d6b95732'}, {'checked': False, 'id': '85795acc-b4b1-4510-bd6e-41648a3553c9'}, {'checked': True, 'at': '2018-01-23T14:23:54.223Z', 'id': 'c185ecdb-48fb-4edb-ae4e-0204ac7a0909', 'submitted': 1, 'correct': True}, {'checked': True, 'at': '2018-01-23T14:23:53.862Z', 'id': '77a66c83-d001-45cd-9a5a-6bba8eb7389e', 'submitted': 1, 'correct': True}], 'user_submitted': True, 'id': 'e6ad8644-96b1-4617-b37b-a263dded202c', 'user_result': 'correct'}, {'user_incomplete': False, 'user_correct': True, 'options': [{'checked': False, 'id': '59b9fc4b-f239-4850-b1f9-912d1fd3ca13'}, {'checked': False, 'id': '2c29e8e8-d4a8-406e-9cdf-de28ec5890fe'}, {'checked': False, 'id': '62feee6e-9b76-4123-bd9e-c0b35126b1f1'}, {'checked': True, 'at': '2018-01-23T14:24:00.807Z', 'id': '7f13df9c-fcbe-4424-914f-2206f106765c', 'submitted': 1, 'correct': True}], 'user_submitted': True, 'id': '95194331-ac43-454e-83de-ea8913067055', 'user_result': 'correct'}], 'attempt': 1, 'id': '5b28a462-7a3b-42e0-b508-09f3906d1703', 'counts': {'incomplete': 1, 'submitted': 4, 'incorrect': 1, 'all_correct': False, 'correct': 2, 'total': 4, 'unanswered': 0}}, 'keen_created_at': '1516717442.735266', 'certification': 'false', 'keen_id': '5a6745820eb8ab00016be1f1', 'exam_name': 'Normal Forms and All That Jazz Master Class'}

Normal Forms and All That Jazz Master Class

1.0

6d4089e4-bde5-4a22-b65f-18bce9ab79c8


```

Try more records from the JSON
```
messages=json.loads(assessment_details_string.select('value').take(1001)[0].value)
messages
print(messages['exam_name'])

```

Exit pyspark using the well formed method:

```
exit()
```


## Tear down the cluster:

```
docker-compose down
```

All 4 containers should be shutdown with the following output.

```
Stopping assignment07bhuvneshsharma_kafka_1 ... done
Stopping assignment07bhuvneshsharma_mids_1 ... done
Stopping assignment07bhuvneshsharma_zookeeper_1 ... done
Stopping assignment07bhuvneshsharma_spark_1 ... done
Removing assignment07bhuvneshsharma_kafka_1 ... done
Removing assignment07bhuvneshsharma_mids_1 ... done
Removing assignment07bhuvneshsharma_zookeeper_1 ... done
Removing assignment07bhuvneshsharma_spark_1 ... done
Removing network assignment07bhuvneshsharma_default
science@w205s4-crook-9:~/w205/assignment-07-bhuvneshsharma$ 
```


Verify that the cluster is properly down:


```
docker ps -a
```

## Learnings
Created an Architecture where we can have created set up where we have messaging system. We created docker containers of zookeeper , kafka and mids. We downloaded JSON file [ sample file ] using curl. We learnt how to configure docker-compose yml file to connect zookeeper and kafka and mids.
We created an multiple containers using the file system which is on the droplet given by berkeley mids program.We also learnt to create a messaging topic on the kafka system. We executed commands to read JSON file , break the records and publish those records to a kafka messaging system.
We also created a message subcribtion to read those messages real time. We also created a spark session using pyspark and subscribed to the messages. Within the pyspark utility we enabled python and accessed the RDD data frame and performed query. 

The advantages of spark is that we can perform extremely large parallel queries using RDD data set . 

The low latency and an easy-to-use event time support also apply to Kafka Streams. It is a rather focused library, and it’s very well-suited for certain types of tasks. That’s also why some of its design can be so optimized for how Kafka works. And if you need to do a simple Kafka topic-to-topic transformation, count elements by key, enrich a stream with data from another topic, or run an aggregation or only real-time processing — Kafka Streams is for you.

If event time is not relevant and latencies in the seconds range are acceptable, Spark is the first choice. It is stable and almost any type of system can be easily integrated. In addition it comes with every Hadoop distribution. Furthermore, the code used for batch applications can also be used for the streaming applications as the API is the same.



## Future
        - Read individual elements of the individual records from Kafka messaging system and use it for analytics
        - Real time enable publishing of records from a web application.
        - Use spark system to run real time analytics on massively parallely system.
	- Create Analytics application which can processes large amount user data.
	- Integrate with HDFS and other database systems



