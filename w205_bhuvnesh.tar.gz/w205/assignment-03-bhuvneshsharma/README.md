# template-activity-03


# Query Project

- In the Query Project, you will get practice with SQL while learning about
  Google Cloud Platform (GCP) and BiqQuery. You'll answer business-driven
  questions using public datasets housed in GCP. To give you experience with
  different ways to use those datasets, you will use the web UI (BiqQuery) and
  the command-line tools, and work with them in jupyter notebooks.

- We will be using the Bay Area Bike Share Trips Data
  (https://cloud.google.com/bigquery/public-data/bay-bike-share). 

#### Problem Statement
- You're a data scientist at Ford GoBike (https://www.fordgobike.com/), the
  company running Bay Area Bikeshare. You are trying to increase ridership, and
  you want to offer deals through the mobile app to do so. What deals do you
  offer though? Currently, your company has three options: a flat price for a
  single one-way trip, a day pass that allows unlimited 30-minute rides for 24
  hours and an annual membership. 

- Through this project, you will answer these questions: 
  * What are the 5 most popular trips that you would call "commuter trips"?
  * What are your recommendations for offers (justify based on your findings)?


## Assignment 03 - Querying data from the BigQuery CLI - set up 

### What is Google Cloud SDK?
- Read: https://cloud.google.com/sdk/docs/overview

- If you want to go further, https://cloud.google.com/sdk/docs/concepts has
  lots of good stuff.

### Get Going

- Install Google Cloud SDK: https://cloud.google.com/sdk/docs/

- Try BQ from the command line:

  * General query structure

    ```
    bq query --use_legacy_sql=false '
        SELECT count(*)
        FROM
           `bigquery-public-data.san_francisco.bikeshare_trips`'
    ```

### Queries

1. Rerun last week's queries using bq command line tool (Paste your bq
   queries):

- What's the size of this dataset? (i.e., how many trips)

The size of the data set can be queried by the following query

```sql
#standardSQL
SELECT
  COUNT(*)
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
```
the result is 983648

The SQL for size of status Table
```sql
#standardSQL
SELECT
  COUNT(*)
FROM
  `bigquery-public-data.san_francisco.bikeshare_status`
```

the result is 107501619


Google Big Query for the same are 
 
bq query --use_legacy_sql=false '
SELECT count(*)
FROM `bigquery-public-data.san_francisco.bikeshare_trips`'


bq query --use_legacy_sql=false '
SELECT count(*)
FROM `bigquery-public-data.san_francisco.bikeshare_status`'

- What is the earliest start time and latest end time for a trip?

EARLIEST START DATE and LATEST END DATE can be queried by 1 query on the bikeshare_trips table on columns start_date and end_date respectively . We are also using min and max function

Changes MADE BY BHUVNESH FOR ASSIGNMENT
```sql
#standardSQL
SELECT
  MIN(start_date) EARLIESTSTARTDATE,
  MAX(end_date) LATESTENDDATE
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
```

Answer is :
EARLIESTSTARTDATE|LATESTENDDATE
-------------------|---------------
2013-08-29 09:08:00.000 UTC|2016-08-31 23:48:00.000 UTC

GOOGLE BIG QUERY FOR THE SAME WOULD BE
bq query --use_legacy_sql=false '
SELECT
  MIN(start_date) EARLIESTSTARTDATE,
  MAX(end_date) LATESTENDDATE
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`'
 



- How many bikes are there?
We can get the number of bikes from bikeshare_trip table via bike_number column. We are also using distinct and count functions
```sql
#standardSQL
SELECT
  COUNT(DISTINCT bike_number) DISTINCT_BIKES_COUNT
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
```
Answer is : 700

GOOGLE BIG QUERY FOR THE SAME WOULD BE 

bq query --use_legacy_sql=false '
SELECT
  COUNT(DISTINCT bike_number) DISTINCT_BIKES_COUNT
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`'


2. New Query (Paste your SQL query and answer the question in a sentence):

- How many trips are in the morning vs in the afternoon?

Morning trips are defined as trips that began between morning hours (morning 5 AM to 11 AM) and ended in the same hours

Evening trips are defined as trips that begain between evening hours (between 3 PM and 9 PM) and ended in the same hours

```sql
  #standardSQL
SELECT
  COUNTIF( (EXTRACT(HOUR
      FROM
        start_date)>5
      AND EXTRACT(HOUR
      FROM
        start_date)<=11)
    AND (EXTRACT(HOUR
      FROM
        end_date)>5
      AND EXTRACT(HOUR
      FROM
        end_date)<=11 )) AS MORNINGTRIPS,
  COUNTIF( (EXTRACT(HOUR
      FROM
        start_date)>15
      AND EXTRACT(HOUR
      FROM
        start_date)<=21)
    AND (EXTRACT(HOUR
      FROM
        end_date)>15
      AND EXTRACT(HOUR
      FROM
        end_date)<=21 )) AS EVENINGTRIPS
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`

```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
  #standardSQL
SELECT
  COUNTIF( (EXTRACT(HOUR
      FROM
        start_date)>5
      AND EXTRACT(HOUR
      FROM
        start_date)<=11)
    AND (EXTRACT(HOUR
      FROM
        end_date)>5
      AND EXTRACT(HOUR
      FROM
        end_date)<=11 )) AS MORNINGTRIPS,
  COUNTIF( (EXTRACT(HOUR
      FROM
        start_date)>15
      AND EXTRACT(HOUR
      FROM
        start_date)<=21)
    AND (EXTRACT(HOUR
      FROM
        end_date)>15
      AND EXTRACT(HOUR
      FROM
        end_date)<=21 )) AS EVENINGTRIPS
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`'

Answer is 

 MORNINGTRIPS | EVENINGTRIPS
--------------|-------------
385873 | 375263



### Project Questions
Identify the main questions you'll need to answer to make recommendations (list
below, add as many questions as you need).

- Question 1: 
What are the most popular routes with the consumers?
- Question 2: 
 Avergage Commute time via bike during the morning , evening hours?
- Question 3: 
How many docking stations run out of bikes in day , hour within a day
- Question 4:
What are highest and lowest ridership hour within a day
- Question 5:
Can we provide traffic and weather information ?
- Question 6:
Can we provide information around nearby friends and collegues ?
- Question 7:
Can we provide discounts to users who can drop off the bike directly to the users , saving the walk for the consumers to the docking station.
- Question 8:
Peak usage timing for bikes
- Question 9:
Utilization of bikes during peak usage.
- Question 10:
Most popular docking station for drop off
- Question 11:
Most popular docking station for pick up
- Question 12:
Utilization of bikes during peak usage.
- Question 13:
Is there a University /school / college ... Can we create a program for students partnering with education institution
- Question 14:
Can we integrate the bike allocation with train system ?  Assumption is that there are people you take the train to get to the city and then take a bike to their work location ?
- Question 15:
Can we offer holiday / vacation package for bulk book for passes
- Question 16:Number of times the consumer wanted a bike but bike was not available
- Question 17: What is the walking distance of the consumer from the place they look for a station / book a bike to docking station
- Question 18:Corelation between weather and bike ridership




- ...

- Question n: 

### Answers

Answer at least 4 of the questions you identified above You can use either
BigQuery or the bq command line tool.  Paste your questions, queries and
answers below.

- Question 1: What are the top 10 most popular routes with the consumers?
  * Answer:

FREQUENCY|start_station_name|end_station_name
---------|------------------|----------------
9150|Harry Bridges Plaza (Ferry Building)|Embarcadero at Sansome
8508|San Francisco Caltrain 2 (330 Townsend)	|Townsend at 7th	
7620|2nd at Townsend	|Harry Bridges Plaza (Ferry Building)	
6888|Harry Bridges Plaza (Ferry Building)	|2nd at Townsend	
6874|Embarcadero at Sansome	|Steuart at Market	
6836|Townsend at 7th	|San Francisco Caltrain 2 (330 Townsend)	
6351|Embarcadero at Folsom	|San Francisco Caltrain (Townsend at 4th)	
6215 | San Francisco Caltrain (Townsend at 4th)	|Harry Bridges Plaza (Ferry Building)	
6039|Steuart at Market	|2nd at Townsend	
5959|Steuart at Market	|San Francisco Caltrain (Townsend at 4th)


  * SQL query:
 ```sql
#standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  start_station_name,
  end_station_name
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  start_station_name,
  end_station_name
ORDER BY
  FREQUENCY DESC
LIMIT
  10

 ```
GOOGLE BIGQUERY
bq query --use_legacy_sql=false '
#standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  start_station_name,
  end_station_name
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  start_station_name,
  end_station_name
ORDER BY
  FREQUENCY DESC
LIMIT
  10'

- Question 2: Avergage Commute time via bike during the morning , evening hours?
  * Answer:


MORNINGCOMMUTETIME|EVENINGCOMMUTETIME
-----------------|------------------	 
10.267453281260776|12.665109536511721

  * SQL query:

 ```sql

#standardSQL
SELECT
   AVG(TIMESTAMP_DIFF(end_date , start_date,MINUTE)) as MORNINGCOMMUTETIME 
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
WHERE
(EXTRACT(HOUR FROM start_date)>5 AND EXTRACT(HOUR FROM start_date)<=11) AND (EXTRACT(HOUR FROM end_date)>5 AND EXTRACT(HOUR FROM end_date)<=11 )


#standardSQL
SELECT
   AVG(TIMESTAMP_DIFF(end_date , start_date,MINUTE)) as MORNINGCOMMUTETIME 
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
WHERE
(EXTRACT(HOUR FROM start_date)>15 AND EXTRACT(HOUR FROM start_date)<=21) AND (EXTRACT(HOUR FROM end_date)>15 AND EXTRACT(HOUR FROM end_date)<=21 )


 ```
GOOGLE BIGQUERY
bq query --use_legacy_sql=false '
#standardSQL
SELECT
   AVG(TIMESTAMP_DIFF(end_date , start_date,MINUTE)) as MORNINGCOMMUTETIME
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
WHERE
(EXTRACT(HOUR FROM start_date)>5 AND EXTRACT(HOUR FROM start_date)<=11) AND (EXTRACT(HOUR FROM end_date)>5 AND EXTRACT(HOUR FROM end_date)<=11 )'


bq query --use_legacy_sql=false '
#standardSQL
SELECT
   AVG(TIMESTAMP_DIFF(end_date , start_date,MINUTE)) as MORNINGCOMMUTETIME
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
WHERE
(EXTRACT(HOUR FROM start_date)>15 AND EXTRACT(HOUR FROM start_date)<=21) AND (EXTRACT(HOUR FROM end_date)>15 AND EXTRACT(HOUR FROM end_date)<=21 )'


- Question 3:Peak usage timing for bikes
  * Answer:

FREQUENCY|HOUR
---------|----
132464|	8	 
126302|	17	 
96118|	9	 
88755|	16	 
84569|	18	 
67531|	7	 
47626|	15	 
46950|	12	 
43714|	13	 
42782|	10	 
41071|	19	 
40407|	11	 
37852|	14	 
22747|	20	 
20519|	6	 
15258|	21	 
10270|	22
6195|	23	 
5098|	5	 
2929|	0	 
1611|	1	 
1398|	4	 
877|	2	 
605|	3

  * SQL query:

 ```sql
       #standardSQL
SELECT
  COUNT(EXTRACT(HOUR FROM start_date))  as FREQUENCY , EXTRACT(HOUR FROM start_date) HOUR
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
  group by HOUR
  order by FREQUENCY DESC

 ```

GOOGLE BIGQUERY
bq query --use_legacy_sql=false '
       #standardSQL
SELECT
  COUNT(EXTRACT(HOUR FROM start_date))  as FREQUENCY , EXTRACT(HOUR FROM start_date) HOUR
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
  group by HOUR
  order by FREQUENCY DESC'


- Question 4:Most popular docking station for pick up

  * Answer:

FREQUENCY|start_station_name
---------|-----------------
72683|	San Francisco Caltrain (Townsend at 4th)	 
56100|	San Francisco Caltrain 2 (330 Townsend)	 
49062|	Harry Bridges Plaza (Ferry Building)	 
41137|	Embarcadero at Sansome	 
39936|	2nd at Townsend	 
39200|	Temporary Transbay Terminal (Howard at Beale)	 
38531|	Steuart at Market	 
35142|	Market at Sansome	 
34894|	Townsend at 7th	 
30209|	Market at 10th

  * SQL query:
 ```sql
  #standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  start_station_name
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  start_station_name
ORDER BY
  FREQUENCY DESC
LIMIT
  10
 ```
GOOGLE BIGQUERY
bq query --use_legacy_sql=false '
  #standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  start_station_name
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  start_station_name
ORDER BY
  FREQUENCY DESC
LIMIT
  10'

- Question 5:Most popular docking station for drop off

  * Answer:
FREQUENCY|end_station_name
---------|-----------------
92014|	San Francisco Caltrain (Townsend at 4th)	 
58713|	San Francisco Caltrain 2 (330 Townsend)	 
50185|	Harry Bridges Plaza (Ferry Building)	 
46197|	Embarcadero at Sansome	 
44145|	2nd at Townsend	 
40956|	Market at Sansome	 
39598|	Steuart at Market	 
38545|	Townsend at 7th	 
35477|	Temporary Transbay Terminal (Howard at Beale)	 
26762|	Market at 4th

  * SQL query:

 ```sql
  #standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  end_station_name
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  end_station_name
ORDER BY
  FREQUENCY DESC
LIMIT
  10

 ```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
  #standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  end_station_name
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  end_station_name
ORDER BY
  FREQUENCY DESC
LIMIT
  10'


- ...

- Question n:
  * Answer:
  * SQL query:
