---
title: "Assignment 11 for W205 by Bhuvnesh Sharma"
author: "Bhuvnesh Sharma"

---


#  Assignment 11 from Bhuvnesh Sharma for W205

## Executive Summary

In the age of cloud computing , we are exploring new architectures of managed services architectures. Infrastructure container services like docker have containerized the application architectures. 
Uptill now we have been using input JSON to feed a KAFKA queue. In this assignment we would explore how to generate web events which can publish to KAFKA queue.
FLASK web server is going to be used to generate web events via integrating python code 

Massive amount of events are generated on the web. We are planning to create a mobile application which generates different kinds of events which need to be analyzed. We are simulating events which mobile application users would generate. 
The producers of the events would be users using the mobile game application based on this high level architecture.

Conceptual Diagram : 
![ALT TEXT](https://cdn.scotch.io/15775/PRPg1998TfO6VKXTeaTz_illustration.jpg)


In this assignment we integrated kafka and flask . Web events were simulated within the FLASK webserver . Also we would publish events to kafka which could be used for Analytics. We would integrate JUPITER notebooks with spark and then integrate with HDFS as well.

We would explore in future assignment reading parquet files from cloudera HDFS of the webevents and then performing analysis.


## Approach

We would be following approach

- Login to the droplet using the credentials provided.
- Connect to git and clone the repo assignment-08-bhuvneshsharma.
- cd to the directory  assignment 11.
- Configure docker-compose yml file
- explain the YML and different pieces of architecture.
	- kafka
	- zookeeper
        - cloudera
	- mids 
	- spark
- Begin docker
- Create kafka topic.
- Start the Flask server on the mids container using python script configuration.
- Explain Flask configuration.
- Perform events on the Flask server using CURL which should trigger WEB event messages to the kafka topic.
- Extract events
- Transform events.
- Separate events
- Publish to cloudera HDFS
- Explore KAKFACAT to subscribe and read messages.
- Use Jupiter notebook.
	- Extract events
	- Transform events.
	- Separate events
	- Publish to HDFS
- Shutdown the docker.

   We are planning to login to the machine where my student droplet has been configured. From that droplet machine we will spin up a cluster with spark,kafka, zookeeper, and the mids container within Docker.
Create a cluster which can map in directory structure virtually and also have the cluster talk to each other.
Create a instance of Flask Application server which is configured to track the events "buy a sword" , "bug a knife"  and "join guild". These events are published to a kafka queue designed to track these events.
After the events are published to Kafka we can use other analytics tools to analyze it.


### Login to the droplet

Using the account provided by MIDS program login to the droplet

#### Check the directory

```
pwd

cd w205

pwd

```

The result should be as below

```
/home/science/
/home/science/w205
```

### Clone the repository from github

Connect to github using git utility and clone the assignment 11

```
git clone https://github.com/mids-w205-crook/assignment-11-bhuvneshsharma.git

```

####  Move in the directory for the assignment


```
cd /home/science/w205/assignment-11-bhuvneshsharma
```

#### List down all the contents of the directory using following command

```
ls -lrt
```

## Create a docker yml file

Move the assignment directory and make the docker-compose.yml file.

```
cd /home/science/w205/assignment-11-bhuvneshsharma

vi docker-compose.yml
```


Insert the following code to the YML file and save it.

```yml
---
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"
    extra_hosts:
      - "moby:127.0.0.1"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    expose:
      - "9092"
      - "29092"
    extra_hosts:
      - "moby:127.0.0.1"

  cloudera:
    image: midsw205/cdh-minimal:latest
    expose:
      - "8020" # nn
      - "50070" # nn http
      - "8888" # hue
    #ports:
    #- "8888:8888"
    extra_hosts:
      - "moby:127.0.0.1"

  spark:
    image: midsw205/spark-python:0.0.5
    stdin_open: true
    tty: true
    expose:
      - "8888"
    ports:
      - "8888:8888"
    volumes:
      - "/home/science/w205:/w205"
    command: bash
    depends_on:
      - cloudera
    environment:
      HADOOP_NAMENODE: cloudera
    extra_hosts:
      - "moby:127.0.0.1"

  mids:
    image: midsw205/base:latest
    stdin_open: true
    tty: true
    expose:
      - "5000"
    ports:
      - "5000:5000"
    volumes:
      - "/home/science/w205:/w205"
    command: bash
    depends_on:
      - cloudera
    environment:
      HADOOP_NAMENODE: cloudera
    extra_hosts:
      - "moby:127.0.0.1"

  mids:
    image: midsw205/base:latest
    stdin_open: true
    tty: true
    expose:
      - "5000"
    ports:
      - "5000:5000"
    volumes:
      - "/home/science/w205:/w205"
    extra_hosts:
      - "moby:127.0.0.1"


```

Alternatively we can copy the docker yml file from course content directory

```
cp ~/w205/course-content/11-Storing-Data-III/docker-compose.yml .

```


## Understanding docker-compose.yml

The docker-compose.yml is configuring 5 different containers within the cluster. The containers in the cluster are the following
- zookeeper
- kafka
- cloudera
- spark
- mids

###  zookeeper
ZooKeeper is a centralized service for maintaining configuration information, naming, providing distributed synchronization, and providing group services.
Zookeeper is distributed systems configuration management tool. Zookeeper provides multiple features for distributed applications like distributed configuration management, leader election, consensus handling, coordination and locks etc.Zookeeper storing its data on tree like structure. It introduced as Data Tree and nodes introduced as zNodes. Zookeeper follows standard unix notations for file paths.

##### image: confluentinc/cp-zookeeper:latest 
        
This is from where we need to get the configuration of zookeeper. Also the setting is specifing that we need to get the latest configuration.
If configured as following confluentinc/cp-zookeeper:4.0.0 , then it is pointing to use the version 4.0.0

##### ZOOKEEPER_CLIENT_PORT
Removing network assignment11bhuvneshsharma_default
ZOOKEEPER_CLIENT_PORT: 32181
ZOOKEEPER_TICK_TIME: 2000

ZOOKEEPER_CLIENT_PORT is the port on which we are configuring zookeeper , port configured is 32181. ZooKeeper where to listen for connections by clien          ts such as Kafka

##### expose
 These are the ports which are opened


###  kafka
Kafka is Fast, Scalable, Durable, and Fault-Tolerant publish-subscribe messaging system which can be used to real time data streaming. We can introduce Kafka as Distributed Commit Log which follows publish subscribe architecture. Like many publish-subscribe messaging systems, Kafka maintains feeds of messages in topics. Producers write data to topics and consumers read from topics. Since Kafka is a distributed system, topics are partitioned and replicated across multiple nodes.
Messages in Kafka are simple byte arrays(String , JSON etc). When publishing, message can be attached to a key. Producer distributes all the messages with same key into same partition.

Kafka uses Zookeeper to mange following tasks
- Electing a controller - The controller is one of the brokers and is responsible for maintaining the leader/follower relationship for all the partitions. When a node shuts down, it is the controller that tells other replicas to become partition leaders to replace the partition leaders on the node that is going away. Zookeeper is used to elect a controller, make sure there is only one and elect a new one it if it crashes.
- Cluster membership - Which brokers are alive and part of the cluster? this is also managed through ZooKeeper.
- Topic configuration - Which topics exist, how many partitions each has, where are the replicas, who is the preferred leader, what configuration overrides are set for each topic
- Manage Quotas - How much data is each client allowed to read and write
- Access control - Who is allowed to read and write to which topic (old high level consumer). Which consumer groups exist, who are their members and what is the latest offset each group got from each partition


##### image: confluentinc/cp-kafka:latest
This is from where we need to get the configuration of kafka. Also the setting is specifing that we need to get the latest configuration.If configured as following confluentinc/cp-kafka:4.0.0 , then it is pointing to use the version 4.0.0

##### depends_on
This configuration requests points to that the fact that this container of kafka depends on zookeeper container.

##### KAFKA_ZOOKEEPER_CONNECT
Connects to zookeeper container at port 32181
##### KAFKA_ADVERTISED_LISTENERS 
Advertised listeners is required for starting up the Docker image because it is important to think through how other clients are going to connect to kafka. In a Docker environment, you will need to make sure that your clients can connect to Kafka and other services. Advertised listeners is how it gives out a host name that can be reached by the client.
KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092

##### KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR
 This is needed when you are running with a single-node cluster. If you have three or more nodes, you do not need to change this from the default. Current setting is 1.

#####    volumes:
Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

#####    expose:
These are the ports which are exposed.
         - "9092"
         - "29092"
#####   extra_hosts:
        This is moby network which is getting mapped to 127.0.0.1
        - "moby:127.0.0.1"

## 3) mids

#####     image: midsw205/base:latest
This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the latest configuration.
#####   extra_hosts:
This is moby network which is getting mapped to 127.0.0.1
#####    volumes:
        Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

### 4) spark

Spark is a fast and general cluster computing system for Big Data. It provides high-level APIs in Scala, Java, Python, and R, and an optimized engine that supports general computation graphs for data analysis. It also supports a rich set of higher-level tools including Spark SQL for SQL and DataFrames, MLlib for machine learning, GraphX for graph processing, and Spark Streaming for stream processing.

Spark Streaming API enables scalable, high-throughput, fault-tolerant stream processing of live data streams. Data can be ingested from many sources like Kafka, Flume, Twitter, etc., and can be processed using complex algorithms such as high-level functions like map, reduce, join and window. Finally, processed data can be pushed out to filesystems, databases, and live dash-boards. Resilient Distributed Datasets (RDD) is a fundamental data structure of Spark. It is an immutable distributed collection of objects. Each dataset in RDD is divided into logical partitions, which may be computed on different nodes of the cluster.


#####     image: midsw205/spark-python:0.0.5
 This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the spark-python:0.0.5 configuration.
#####    volumes:
Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.
#####    command
The default Shell that needs to be open as first command
#####   extra_hosts:
 This is moby network which is getting mapped to 127.0.0.1
 - "moby:127.0.0.1"
#####    stdin_open
#####    tty
A tty is essentially a text input output environment aka shell.


### 5) cloudera
Cloudera is the Hadoop set up

####     image: midsw205/cdh-minimal:latest
 This is from where we need to get the configuration of cloudera. Also the setting is specifing that we need to get the midsw205/cdh-minimal:latest  configuration.

####  expose
These are the ports which are exposed.
      - "8020" # nn
      - "50070" # nn http
      - "8888" # hue


## FLASK

Flask is a micro web framework written in Python. It is classified as a microframework because it does not require particular tools or libraries. ... Applications that use the Flask framework include Pinterest, LinkedIn, and the community web page for Flask itself.

The microframework Flask is based on the Pocoo projects Werkzeug and Jinja2.

Lightweight web framework Flask and set up a basic web server with different pages using Python, HTML, and CSS.

While lightweight and easy to use, Flask’s built-in server is not suitable for production as it doesn’t scale well.

## FLASK COMPONENTS

### Werkzeug
Werkzeug is a utility library for the Python programming language, in other words a toolkit for Web Server Gateway Interface (WSGI) applications, and is licensed under a BSD License. Werkzeug can realize software objects for request, response, and utility functions. It can be used to build a custom software framework on top of it and supports Python 2.6, 2.7 and 3.3

### Jinja
Jinja is a template engine for the Python programming language and is licensed under a BSD License also by Ronacher. Similar to the Django web framework, furthermore it provides that templates are evaluated in a sandbox.


## FLASK SET UP - MIDS

let us create the python file which is going to be invoked with FLASK server is invoked.

Move the assignment directory and make the game_api.py file.

```
cd /home/science/w205/assignment-11-bhuvneshsharma

vi game_api.py
```

Paste the following code in the game_api.py file 


```python
#!/usr/bin/env python
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='kafka:29092')


def log_to_kafka(topic, event):
    event.update(request.headers)
    producer.send(topic, json.dumps(event).encode())


@app.route("/")
def default_response():
    default_event = {'event_type': 'default'}
    log_to_kafka('events', default_event)
    return "\nThis is the default response!\n"


@app.route("/purchase_a_sword")
def purchase_a_sword():
    purchase_sword_event = {'event_type': 'purchase_sword'}
    log_to_kafka('events', purchase_sword_event)
    return "\nSword Purchased!\n"

```

app is the class and route is the method which is getting invoked. This is called decorators.

Above code behaves in the following way 

1.) if the URL of the application directly is hit it invokes the event @app.route("/") and the response if "\nThis is the default response!\n".

2.) if the URL of the application /purchase_a_sword it invokes the event @app.route("/purchase_a_sword") and the response if return "\nSword Purchased!\n"

Also the above code is publishing to the event on the kafka queue using the custom method log_to_kafka. log_to_kafka sends the json dump along with headers to the kafka server which is defined by producer

## Docker

Bring up the docker cluster. The -d option tells us to detach the cluster from the current terminal - essentiall it will run "headless".
It is important to run the command from the directory where docker-compose.yml. If we are in a directory without a docker-compose.yml file, docker-compose will throw an error.

```
docker-compose up -d
```

Following output should be on the screen .

```
Creating network "assignment11bhuvneshsharma_default" with the default driver
Creating assignment11bhuvneshsharma_cloudera_1
Creating assignment11bhuvneshsharma_zookeeper_1
Creating assignment11bhuvneshsharma_mids_1
Creating assignment11bhuvneshsharma_spark_1
Creating assignment11bhuvneshsharma_kafka_1

```


If you want to see the kafka logs live as it comes up use the following command. The -f tells it to keep checking the file for any new additions to the file and print them. To stop this command, use a control-C:

```
docker-compose logs -f kafka
```

Following output is what we should  see

```
kafka_1      | [2018-07-29 18:19:51,392] TRACE [Broker id=1] Completed LeaderAndIsr request correlationId 1 from controller 1 epoch 1 for the become-leader transition for partition __confluent.support.metrics-0 (state.change.logger)
kafka_1      | [2018-07-29 18:19:51,399] INFO [ReplicaAlterLogDirsManager on broker 1] Added fetcher for partitions List() (kafka.server.ReplicaAlterLogDirsManager)
kafka_1      | [2018-07-29 18:19:51,410] TRACE [Controller id=1 epoch=1] Received response {error_code=0,partitions=[{topic=__confluent.support.metrics,partition=0,error_code=0}]} for request LEADER_AND_ISR with correlation id 1 sent to broker kafka:29092 (id: 1 rack: null) (state.change.logger)
kafka_1      | [2018-07-29 18:19:51,415] TRACE [Broker id=1] Cached leader info PartitionState(controllerEpoch=1, leader=1, leaderEpoch=0, isr=[1], zkVersion=0, replicas=[1], offlineReplicas=[]) for partition __confluent.support.metrics-0 in response to UpdateMetadata request sent by controller 1 epoch 1 with correlation id 2 (state.change.logger)
kafka_1      | [2018-07-29 18:19:51,416] TRACE [Controller id=1 epoch=1] Received response {error_code=0} for request UPDATE_METADATA with correlation id 2 sent to broker kafka:29092 (id: 1 rack: null) (state.change.logger)
kafka_1      | [2018-07-29 18:19:51,423] INFO Kafka version : 1.1.1-cp1 (org.apache.kafka.common.utils.AppInfoParser)
kafka_1      | [2018-07-29 18:19:51,423] INFO Kafka commitId : 0a5db4d59ee15a47 (org.apache.kafka.common.utils.AppInfoParser)
kafka_1      | [2018-07-29 18:19:51,463] INFO Cluster ID: f3DHfJgxSM2VGoc2LGCe9A (org.apache.kafka.clients.Metadata)
kafka_1      | [2018-07-29 18:19:51,520] INFO Updated PartitionLeaderEpoch. New: {epoch:0, offset:0}, Current: {epoch:-1, offset:-1} for Partition: __confluent.support.metrics-0. Cache now contains 0 entries. (kafka.server.epoch.LeaderEpochFileCache)
kafka_1      | [2018-07-29 18:19:51,549] INFO [Producer clientId=producer-1] Closing the Kafka producer with timeoutMillis = 9223372036854775807 ms. (org.apache.kafka.clients.producer.KafkaProducer)
kafka_1      | [2018-07-29 18:19:51,557] INFO Successfully submitted metrics to Kafka topic __confluent.support.metrics (io.confluent.support.metrics.submitters.KafkaSubmitter)
kafka_1      | [2018-07-29 18:19:52,373] INFO Successfully submitted metrics to Confluent via secure endpoint (io.confluent.support.metrics.submitters.ConfluentSubmitter)

```
Press Control C to exit out of the tail -f command 
Check and see if our cluster is running. This checks if the docker processes are up and running.

```
docker-compose ps
```

Following output is what we should  see

```
                 Name                             Command            State                                         Ports                                        
---------------------------------------------------------------------------------------------------------------------------------------------------------------
assignment11bhuvneshsharma_cloudera_1    cdh_startup_script.sh       Up      11000/tcp, 11443/tcp, 19888/tcp, 50070/tcp, 8020/tcp, 8088/tcp, 8888/tcp, 9090/tcp 
assignment11bhuvneshsharma_kafka_1       /etc/confluent/docker/run   Up      29092/tcp, 9092/tcp                                                                
assignment11bhuvneshsharma_mids_1        /bin/bash                   Up      0.0.0.0:5000->5000/tcp, 8888/tcp                                                   
assignment11bhuvneshsharma_spark_1       docker-entrypoint.sh bash   Up      0.0.0.0:8888->8888/tcp                                                             
assignment11bhuvneshsharma_zookeeper_1   /etc/confluent/docker/run   Up      2181/tcp, 2888/tcp, 32181/tcp, 3888/tcp                                            

```

```
docker ps -a
```

You should see the following message to let us know the topic assessment was created correctly:

```
ONTAINER ID        IMAGE                              COMMAND                  CREATED             STATUS              PORTS                                                                                NAMES
559d01dd2605        confluentinc/cp-kafka:latest       "/etc/confluent/dock…"   2 minutes ago       Up 2 minutes        9092/tcp, 29092/tcp                                                                  assignment11bhuvneshsharma_kafka_1
ca438d509650        midsw205/spark-python:0.0.5        "docker-entrypoint.s…"   2 minutes ago       Up 2 minutes        0.0.0.0:8888->8888/tcp                                                               assignment11bhuvneshsharma_spark_1
128ec04c46b6        midsw205/base:latest               "/bin/bash"              2 minutes ago       Up 2 minutes        0.0.0.0:5000->5000/tcp, 8888/tcp                                                     assignment11bhuvneshsharma_mids_1
2b652eaaddb8        confluentinc/cp-zookeeper:latest   "/etc/confluent/dock…"   2 minutes ago       Up 2 minutes        2181/tcp, 2888/tcp, 3888/tcp, 32181/tcp                                              assignment11bhuvneshsharma_zookeeper_1
d7422313108c        midsw205/cdh-minimal:latest        "cdh_startup_script.…"   2 minutes ago       Up 2 minutes        8020/tcp, 8088/tcp, 8888/tcp, 9090/tcp, 11000/tcp, 11443/tcp, 19888/tcp, 50070/tcp   assignment11bhuvneshsharma_cloudera_1

```

## Cloudera set up

Wait for the cluster to come up. Open a separate linux command line window for each of these. Cloudera hadoop may take a while to come up. You may want to also check the hadoop file system to see how eventual consistency works for the two directories for yarn and hive to both show up. You may also want to check kafka. Sometimes kafka has to reorg and it can take a while to come up. Remember to use control-C to exit processes with the -f option.

```
docker-compose logs -f cloudera
docker-compose exec cloudera hadoop fs -ls /tmp/
```

Following output should appear on the screen

```
cloudera_1   | Start Components
cloudera_1   | Press Ctrl+P and Ctrl+Q to background this process.
cloudera_1   | Use exec command to open a new bash instance for this instance (Eg. "docker exec -i -t CONTAINER_ID bash"). Container ID can be obtained using "docker ps" command.
cloudera_1   | Start Terminal
cloudera_1   | Press Ctrl+C to stop instance.
```

```
science@w205s4-crook-9:~/w205/assignment-11-bhuvneshsharma$ docker-compose exec cloudera hadoop fs -ls /tmp/
Found 2 items
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2018-07-29 18:20 /tmp/hive
```

## Create a topic within kafka
Create a topic called "events" in the kafka container using the kafka-topics utility with the following command.

```
docker-compose exec kafka \
   kafka-topics \
     --create \
     --topic events \
     --partitions 1 \
     --replication-factor 1 \
     --if-not-exists \
     --zookeeper zookeeper:32181
```
	
Same command in 1 line which creates "events" topic

```
docker-compose exec kafka kafka-topics --create --topic events --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```

You should see the following message to let us know the topic assessment was created correctly:

```
Created topic "events".
```

Check the topic in the kafka container using the kafka-topics utility:

```
		docker-compose exec kafka \
			  kafka-topics \
			  --describe \
			  --topic assessment \
			  --zookeeper zookeeper:32181
```

Single line command is as follows

```
docker-compose exec kafka kafka-topics --describe --topic events --zookeeper zookeeper:32181
```

You should see the following message

```
Topic:events	PartitionCount:1	ReplicationFactor:1	Configs:
Topic: events	Partition: 0	Leader: 1	Replicas: 1	Isr: 1
```


## Start FLASK 

Inorder to run the FLASK server , we are invoking the microservice below that starts with game_api.py. This is with Default setting of the python file.

```
docker-compose exec mids \
  env FLASK_APP=/w205/spark-from-files/game_api.py \
  flask run --host 0.0.0.0
```

```
docker-compose exec mids env FLASK_APP=/w205/spark-from-files/game_api.py flask run --host 0.0.0.0

```

Following output should be recieved on the the window

```
 * Serving Flask app "game_api"
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
```


## Now generate events using curl:

## WHAT IS CURL

cURL is a computer software project providing a library and command-line tool for transferring data using various protocols. The cURL project produces two products, libcurl and cURL. It was first released in 1997. The name stands for "Client URL".


We are simulating a invokation of the website using following microservice using curl command. Curl allows us to submit the http request to localhost on mids container. 
Note: the flask server is also running on MIDS container.

```
docker-compose exec mids curl http://localhost:5000/
docker-compose exec mids curl http://localhost:5000/purchase_a_sword
```

We should notice following in the flask logs

```
127.0.0.1 - - [16/Jul/2018 02:08:59] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:12:24] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:12:30] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:12:41] "GET / HTTP/1.1" 200 -
```

Also we should also see following in the reponse window. These are the responses which we have coded in the python files. If we had invovked the same from a browser manually we would have got these messages in the browser window.

```
This is the default response!
Sword Purchased!
```

Read the topic in kafka to see the generated events (same as we have done before):


```
docker-compose exec mids \
  kafkacat -C -b kafka:29092 -t events -o beginning -e
```

Same command but on 1 line for convenience:

```
docker-compose exec mids kafkacat -C -b kafka:29092 -t events -o beginning -e
```

Following output is recieved from the kafka queue

```
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
```


## Integrate FLASK python code with KAFKA and 2 event

let us create a new  python file which is going to be invoked with FLASK server is invoked.

Move the assignment directory and make the game_api_event.py file.

```
cd /home/science/w205/assignment-11-bhuvneshsharma
 
vi game_api_event.py
```

Paste the following code in the game_api_event.py file


```python
#!/usr/bin/env python
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='kafka:29092')


def log_to_kafka(topic, event):
    event.update(request.headers)
    producer.send(topic, json.dumps(event).encode())


@app.route("/")
def default_response():
    default_event = {'event_type': 'default'}
    log_to_kafka('events', default_event)
    return "\nThis is the default response!\n"


@app.route("/purchase_a_sword")
def purchase_a_sword():
    purchase_sword_event = {'event_type': 'purchase_sword'}
    log_to_kafka('events', purchase_sword_event)
    return "\nSword Purchased!\n"

@app.route("/purchase_a_knife")
def purchase_a_knife():
    purchase_knife_event = {'event_type': 'purchase_knife'}
    log_to_kafka('events', purchase_knife_event)
    return "\nKnife Purchased!\n"
```

Above code behaves in the following way

1.) if the URL of the application directly is hit it invokes the event @app.route("/") and the response if "\nThis is the default response!\n".

2.) if the URL of the application /purchase_a_sword it invokes the event @app.route("/purchase_a_sword") and the response  return "\nSword Purchased!\n" . It also invokes the kafka message queue "events" and post a message event purchased_sword


3.) if the URL of the application /purchase_a_knife it invokes the event @app.route("/purchase_a_knife") and the response  return "\nKnife Purchased!\n" . It also invokes the kafka message queue "events" and post a message event purchased_knife

Also the above code is publishing to the event on the kafka queue using the custom method log_to_kafka. log_to_kafka sends the json dump along with headers to the kafka server which is defined by producer


## Start FLASK with game_api_event python file 

Inorder to run the FLASK server , we are invoking the microservice below that starts with game_api_event.py. This flask can also be accessed directly by a browser as well. We need to replace the docklet IP inorder to invoke the transaction.

```
docker-compose exec mids env FLASK_APP=/w205/assignment-11-bhuvneshsharma/game_api_event.py flask run  --host 0.0.0.0
```

Following output should be recieved on the the window

```
 * Serving Flask app "game_api_event.py""
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
```
You can generate HTTP traffic via a browser from your own machine using 
http://138.68.44.59:5000/
http://138.68.44.59:5000/purchase_sword
http://138.68.44.59:5000/purchase_a_knife

Headers would be different from this route compared to curl method mentioned below.


## Now generate events using curl:

We are simulating a invokation of the website using following microservice using curl command. Curl allows us to submit the http request to localhost on mids container.
Note: the flask server is also running on MIDS container.

```
docker-compose exec mids curl http://localhost:5000/
docker-compose exec mids curl http://localhost:5000/purchase_a_sword
docker-compose exec mids curl http://localhost:5000/purchase_a_knife
```

We notice following in the flask logs

```
127.0.0.1 - - [16/Jul/2018 02:20:07] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:12] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:20] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:21] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:22] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:24] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:25] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:26] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:28] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:30] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:30] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:20:32] "GET /purchase_a_knife HTTP/1.1" 200 -

```

Also we should also see following in the reponse window. These are the responses which we have coded in the python files. If we had invovked the same from a browser manually we would have got these messages in the browser window.

```
This is the default response!
Sword Purchased!
```

Now lets see if we captured the events in Kafka queue.

```
docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```

Following output is recieved which proves that kafka queue had the events captured.

```
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
% Reached end of topic events [0] at offset 10: exiting

```


## Integrate FLASK python code with KAFKA and all events


let us create a new  python file which is going to be invoked with FLASK server is invoked.

Move the assignment directory and make the game_api_all_events.py file.

```
cd /home/science/w205/assignment-11-bhuvneshsharma

vi game_api_all_events.py
```

Paste the following code in the game_api_all_events.py file


```python
#!/usr/bin/env python
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='kafka:29092')


def log_to_kafka(topic, event):
    event.update(request.headers)
    producer.send(topic, json.dumps(event).encode())


@app.route("/")
def default_response():
    default_event = {'event_type': 'default'}
    log_to_kafka('events', default_event)
    return "\nThis is the default response!\n"


@app.route("/purchase_a_sword")
def purchase_a_sword():
    purchase_sword_event = {'event_type': 'purchase_sword'}
    log_to_kafka('events', purchase_sword_event)
    return "\nSword Purchased!\n"

@app.route("/purchase_a_knife")
def purchase_a_knife():
    purchase_knife_event = {'event_type': 'purchase_knife'}
    log_to_kafka('events', purchase_knife_event)
    return "\nKnife Purchased!\n"

@app.route("/join_a_guild")
def join_guild():
    join_guild = {'event_type': 'join_guild'}
    log_to_kafka('events', join_guild)
    return "\nGuild Joined!\n"
```

Above code behaves in the following way

1.) if the URL of the application directly is hit it invokes the event @app.route("/") and the response if "\nThis is the default response!\n".

2.) if the URL of the application /purchase_a_sword it invokes the event @app.route("/purchase_a_sword") and the response  return "\nSword Purchased!\n" . It also invokes the kafka message queue "events" and post a message event purchased_sword.

3.) if the URL of the application /purchase_a_knife , it invokes the event @app.route("/purchase_a_knife") and the response  return "\nKnife Purchased!\n" . It also invokes the kafka message queue "events" and post a message event purchased_knife.

4.) if the URL of the application /join_a_guild , it invokes the event @app.route("/join_a_guild") and  the response  return return "\nGuild Joined!\n" . It also invokes the kafka message queue "events" and post a message event joined_guild.

Also the above code is publishing to the event on the kafka queue using the custom method log_to_kafka. log_to_kafka sends the json dump along with headers to the kafka server which is defined by producer

## Start FLASK 

Inorder to run the FLASK server , we are invoking the microservice below that starts with game_api_all_events.py..

```
docker-compose exec mids env FLASK_APP=/w205/assignment-11-bhuvneshsharma/game_api_all_events.py flask run  --host 0.0.0.0
```

Following output should be recieved on the the window

```
 * Serving Flask app "game_api_all_events.py""
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
```


## Now generate events using curl:

We are simulating a invokation of the website using following microservice using curl command. Curl allows us to submit the http request to localhost on mids container.
Note: the flask server is also running on MIDS container.

```
docker-compose exec mids curl http://localhost:5000/
docker-compose exec mids curl http://localhost:5000/purchase_a_sword
docker-compose exec mids curl http://localhost:5000/purchase_a_knife
docker-compose exec mids curl http://localhost:5000/join_a_guild
```

We should notice following in the flask logs

```
127.0.0.1 - - [16/Jul/2018 02:34:23] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:28] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:34] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:39] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:46] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:51] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:55] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:34:58] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:00] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:02] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:04] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:18] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:29] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:30] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:32] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:34] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [16/Jul/2018 02:35:40] "GET /purchase_a_sword HTTP/1.1" 200 -
```

Also we should also see following in the reponse window

```
This is the default response!
Sword Purchased!
Knife Purchased!
Guild Joined!
```

Now lets see if we captured the events in Kafka queue.

```
docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```

Following output is recieved which proves that kafka queue had the events captured.

```
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
% Reached end of topic events [0] at offset 21: exiting

```


## Integrate FLASK python code with KAFKA and all events and INSERT Headers.


let us create a new  python file which is going to be invoked with FLASK server is invoked.


Move the assignment directory and make the game_api_with_extended_json_events.py file.

```
cd /home/science/w205/assignment-11-bhuvneshsharma
vi game_api_with_extended_json_events.py
```

Paste the following code in the game_api_with_extended_json_events.py file


```python
#!/usr/bin/env python
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='kafka:29092')


def log_to_kafka(topic, event):
    event.update(request.headers)
    producer.send(topic, json.dumps(event).encode())


@app.route("/")
def default_response():
    default_event = {'event_type': 'default'}
    log_to_kafka('events', default_event)
    return "\nThis is the default response!\n"


@app.route("/purchase_a_sword")
def purchase_a_sword():
    purchase_sword_event = {'event_type': 'purchase_sword'}
    log_to_kafka('events', purchase_sword_event)
    return "\nSword Purchased!\n"


@app.route("/purchase_a_knife")
def purchase_knife():
    # business logic to purchase knife
    # log event to kafka
    purchase_knife_event = {'event_type': 'purchase_knife'}
    event_logger.send(events_topic, 'purchased_knife'.encode())
    return "\nKnife Purchased!\n"

@app.route("/join_a_guild")
def join_guild():
    # business logic to purchase sword
    # log event to kafka
    join_guild_event = {'event_type': 'join_guild'}
    event_logger.send(events_topic, 'joined_guild'.encode())
    return "\nGuild Joined!\n"

```

Above code behaves in the following way

1.) if the URL of the application directly is hit it invokes the event @app.route("/") and the response if "\nThis is the default response!\n".

2.) if the URL of the application /purchase_a_sword it invokes the event @app.route("/purchase_a_sword") and the response  return "\nSword Purchased!\n" . It also invokes the kafka message queue "events" and post a message event purchased_sword.

3.) if the URL of the application /purchase_a_knife , it invokes the event @app.route("/purchase_a_knife") and the response  return "\nKnife Purchased!\n" . It also invokes the kafka message queue "events" and post a message event purchased_knife.

4.) if the URL of the application /join_a_guild , it invokes the event @app.route("/join_a_guild") and  the response  return return "\nGuild Joined!\n" . It also invokes the kafka message queue "events" and post a message event joined_guild.

The menthod event_logger is performing the update using the request headers and then sending to kafka topic as a JSON dump.
We can perform other business logic like performing credit card transaction 



## Start FLASK

Inorder to run the FLASK server , we are invoking the microservice below that starts with game_api_with_extended_json_events.py

```
docker-compose exec mids env FLASK_APP=/w205/assignment-11-bhuvneshsharma/game_api_with_extended_json_events.py flask run
```

Following output should be recieved on the the window

```
 * Serving Flask app "game_api_with_extended_json_events.py""
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
```


## Now generate events using curl:

We are simulating a invokation of the website using following microservice using curl command. Curl allows us to submit the http request to localhost on mids container.
Note: the flask server is also running on MIDS container.

```
docker-compose exec mids curl http://localhost:5000/
docker-compose exec mids curl http://localhost:5000/purchase_a_sword
docker-compose exec mids curl http://localhost:5000/purchase_a_knife
docker-compose exec mids curl http://localhost:5000/join_a_guild
```

We should notice following in the flask logs

```
127.0.0.1 - - [23/Jul/2018 02:17:34] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:38] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:42] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:47] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:53] "GET / HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:57] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:58] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:17:59] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:00] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:04] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:05] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:05] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:06] "GET /purchase_a_knife HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:11] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:17] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:18] "GET /join_a_guild HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:19] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:21] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:22] "GET /purchase_a_sword HTTP/1.1" 200 -
127.0.0.1 - - [23/Jul/2018 02:18:26] "GET / HTTP/1.1" 200 -
```

Also we should also see following in the reponse window

```
This is the default response!
Sword Purchased!
Knife Purchased!
Guild Joined!
```

Now lets see if we captured the events in Kafka queue.

```
docker-compose exec mids bash -c "kafkacat -C -b kafka:29092 -t events -o beginning -e"
```

Following output is recieved which proves that kafka queue had the events captured.

```
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_knife", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "join_guild", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "purchase_sword", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
{"Host": "localhost:5000", "event_type": "default", "Accept": "*/*", "User-Agent": "curl/7.47.0"}
% Reached end of topic events [0] at offset 20: exiting
```


## SPARK SUBMIT

### Extract events using python via spark submit

Open the following python file to extract events files.

```
vi extract_event.py
```

Paste the following code 

```python
#!/usr/bin/env python
"""Extract events from kafka and write them to hdfs
"""
import json
from pyspark.sql import SparkSession


def main():
    """main
    """
    spark = SparkSession \
        .builder \
        .appName("ExtractEventsJob") \
        .getOrCreate()

    raw_events = spark \
        .read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "events") \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()

    events = raw_events.select(raw_events.value.cast('string'))
    extracted_events = events.rdd.map(lambda x: json.loads(x.value)).toDF()

    extracted_events \
        .write \
        .parquet("/tmp/extracted_events")


if __name__ == "__main__":
    main()
```


The above code reads the kafka queue on the kafka:29092 and from earliest message to latest message. After that it converts the json input as data frame. Finally the code writes the extracted events as parquet files on cloudera hadoop cluster.

Submit our extract_events.py file to spark using spark-submit:
Spark submit : The spark-submit script in Spark’s bin directory is used to launch applications on a cluster. It can use all of Spark’s supported cluster managers through a uniform interface so you don’t have to configure your application especially for each one.

```
docker-compose exec spark \
  spark-submit \
    /w205/spark-from-files/extract_events.py

```

Single line code for executing the extract events

```
docker-compose exec spark spark-submit /w205/spark-from-files/extract_events.py

```

Lets now check if the python file wrote in HDFS set up @ CLOUDERA

```
docker-compose exec cloudera hadoop fs -ls /tmp/
docker-compose exec cloudera hadoop fs -ls /tmp/extracted_events/
```

Following out put is recieved when we run the commands

```
drwxr-xr-x   - root   supergroup          0 2018-07-29 20:31 /tmp/extracted_events
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2018-07-29 20:08 /tmp/hive
```

When we look into the direction /tmp/extracted_events ... there should be 2 files ... 
1.) _SUCCESS
2.) Parquet file

```
science@w205s4-crook-9:~/w205/assignment-11-bhuvneshsharma$ docker-compose exec cloudera hadoop fs -ls /tmp/extracted_events/
Found 2 items
-rw-r--r--   1 root supergroup          0 2018-07-29 20:31 /tmp/extracted_events/_SUCCESS
-rw-r--r--   1 root supergroup       1216 2018-07-29 20:31 /tmp/extracted_events/part-00000-ffcc5299-8503-4c7a-9b96-972d08b2d00a-c000.snappy.parquet
```


## Transform events


### Run transform_events.py and review the results.

```
vi transform_events.py
```

paste the following code for transforming and writing back to HDFS


```python
#!/usr/bin/env python
"""Extract events from kafka, transform, and write to hdfs
"""
import json
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import udf


@udf('string')
def munge_event(event_as_json):
    event = json.loads(event_as_json)
    event['Host'] = "BHUVNESH-MACHINE" 
    event['Cache-Control'] = "no-cache"
    return json.dumps(event)


def main():
    """main
    """
    spark = SparkSession \
        .builder \
        .appName("ExtractEventsJob") \
        .getOrCreate()

    raw_events = spark \
        .read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "events") \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()
    raw_events.show()

    munged_events = raw_events \
        .select(raw_events.value.cast('string').alias('raw'),
                raw_events.timestamp.cast('string')) \
        .withColumn('munged', munge_event('raw'))
    munged_events.show()

    extracted_events = munged_events \
        .rdd \
        .map(lambda r: Row(timestamp=r.timestamp, **json.loads(r.munged))) \
        .toDF()
    extracted_events.show()

    extracted_events \
        .write \
        .mode("overwrite") \
        .parquet("/tmp/extracted_events")


if __name__ == "__main__":
    main()
```

Above Code works as follows

- Creates a Spark session and name the job as ExtractEventsJob
- Read the kafka server @ port 29092 on name kakfa
- Kafka queue is read from start to end
- Raw events are read and tranformed as string.
- Lambda tranform the json as data frame.
- munge event tranforms Host in the header as BHUVNESH-MACHINE instead of Localhost. Where as it add Cache-Control to no-cache
- write the extracted events to HDFS



Run the above code via spark submit

```
docker-compose exec spark spark-submit /w205/spark-from-files/transform_events.py

```

Run the cloudera to check the output @ HDFS using following command.

```
docker-compose exec cloudera hadoop fs -ls /tmp/extracted_events/

```

Following output is recieved.

```
Found 2 items
-rw-r--r--   1 root supergroup          0 2018-07-29 20:36 /tmp/extracted_events/_SUCCESS
-rw-r--r--   1 root supergroup       1918 2018-07-29 20:36 /tmp/extracted_events/part-00000-45e91f2d-08bb-4436-b93c-7c92abdb78db-c000.snappy.parquet

```

## SEPARATE EVENTS.

### Run separate_events.py and review results.

```
vi separate_events.py
```

```python
#!/usr/bin/env python
"""Extract events from kafka and write them to hdfs
"""
import json
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import udf


@udf('string')
def munge_event(event_as_json):
    event = json.loads(event_as_json)
    event['Host'] = "BHUVNESH_MACHINE" # silly change to show it works
    event['Cache-Control'] = "no-cache"
    return json.dumps(event)


def main():
    """main
    """
    spark = SparkSession \
        .builder \
        .appName("ExtractEventsJob") \
        .getOrCreate()

    raw_events = spark \
        .read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "events") \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()

    munged_events = raw_events \
        .select(raw_events.value.cast('string').alias('raw'),
                raw_events.timestamp.cast('string')) \
        .withColumn('munged', munge_event('raw'))

    extracted_events = munged_events \
        .rdd \
        .map(lambda r: Row(timestamp=r.timestamp, **json.loads(r.munged))) \
        .toDF()

    sword_purchases = extracted_events \
        .filter(extracted_events.event_type == 'purchase_sword')
    sword_purchases.show()
     sword_purchases \
         .write \
         .mode("overwrite") \
         .parquet("/tmp/sword_purchases")

    knife_purchases = extracted_events \
        .filter(extracted_events.event_type == 'purchase_knife')
    knife_purchases.show()
     knife_purchases \
         .write \
         .mode("overwrite") \
         .parquet("/tmp/knife_purchases")

    join_guild = extracted_events \
        .filter(extracted_events.event_type == 'join_guild')
    join_guild.show()
     join_guild \
         .write \
         .mode("overwrite") \
         .parquet("/tmp/join_guild")

    default_hits = extracted_events \
        .filter(extracted_events.event_type == 'default')
    default_hits.show()
     default_hits \
         .write \
         .mode("overwrite") \
         .parquet("/tmp/default_hits")

if __name__ == "__main__":
    main()
```


Above Code works as follows

- Creates a Spark session and name the job as ExtractEventsJob
- Read the kafka server @ port 29092 on name kakfa
- Kafka queue is read from start to end
- Raw events are read and tranformed as string.
- Lambda tranform the json as data frame.
- Check if events are purchase_sword then write to HDFS in /tmp/sword_purchases
- Check if events are purchase_knife then write to HDFS in /tmp/knife_purchases
- Check if events are join_guild then write to HDFS in /tmp/join_guild
- Check if events are default then write to HDFS in /tmp/default_hits
- write the extracted events to HDFS

Run the following code to using spark submit

```
docker-compose exec spark spark-submit /w205/spark-from-files/separate_events.py

```

Check directories on HDFS

```
docker-compose exec cloudera hadoop fs -ls /tmp/
docker-compose exec cloudera hadoop fs -ls /tmp/sword_purchases/
docker-compose exec cloudera hadoop fs -ls /tmp/knife_purchases/
docker-compose exec cloudera hadoop fs -ls /tmp/join_guild/
docker-compose exec cloudera hadoop fs -ls /tmp/default_hits/
```


Check directories on HDFS


```
docker-compose exec cloudera hadoop fs -ls /tmp/

```

```
Found 7 items
drwxr-xr-x   - root   supergroup          0 2018-07-30 00:23 /tmp/default_hits
drwxr-xr-x   - root   supergroup          0 2018-07-30 00:07 /tmp/extracted_events
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2018-07-29 23:44 /tmp/hive
drwxr-xr-x   - root   supergroup          0 2018-07-30 00:20 /tmp/join_guild
drwxr-xr-x   - root   supergroup          0 2018-07-30 00:21 /tmp/purchase_knife
drwxr-xr-x   - root   supergroup          0 2018-07-30 00:22 /tmp/purchase_sword

```


### kafcat
kafkacat is a command line utility that you can use to test and debug Apache Kafka deployments. You can use kafkacat to produce, consume, and list topic and partition information for Kafka. Described as “netcat for Kafka”, it is a swiss-army knife of tools for inspecting and creating data in Kafka.


## PYSPARK to perform the Analysis of KAFKA

Run a pyspark shell

```
docker-compose exec spark pyspark
```

```
raw_events = spark \
  .read \
  .format("kafka") \
  .option("kafka.bootstrap.servers", "kafka:29092") \
  .option("subscribe","events") \
  .option("startingOffsets", "earliest") \
  .option("endingOffsets", "latest") \
  .load() 
```

```
raw_events = spark.read.format("kafka").option("kafka.bootstrap.servers", "kafka:29092").option("subscribe","events").option("startingOffsets", "earliest").option("endingOffsets", "latest").load() 
```

Cache our raw events:


```
raw_events.cache()
raw_events.show()
raw_events.printSchema()
```

 Following output is observed

```
+----+--------------------+------+---------+------+--------------------+-------------+
| key|               value| topic|partition|offset|           timestamp|timestampType|
+----+--------------------+------+---------+------+--------------------+-------------+
|null|[7B 22 48 6F 73 7...|events|        0|     0|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     1|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     2|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     3|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     4|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     5|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     6|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     7|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     8|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     9|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    10|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    11|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    12|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    13|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    14|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    15|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    16|2018-07-23 02:29:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    17|2018-07-23 02:30:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    18|2018-07-23 02:30:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    19|2018-07-23 02:30:...|            0|
+----+--------------------+------+---------+------+--------------------+-------------+
only showing top 20 rows

```
 Following output is observed

```
 raw_events.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)

```

The value will be binary which is not easily human readable. We won't be using the other attributes. We will create a new data frame with just the value in string format.

```
events = raw_events.select(raw_events.value.cast('string'))
events.show()
events.printSchema()
```

 Following output is observed when we perform show command


```
+--------------------+
|               value|
+--------------------+
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
|{"Host": "localho...|
+--------------------+
only showing top 20 rows

```

 Following output is observed

```
events.printSchema()
root
 |-- value: string (nullable = true)

```

Import JSON package and perform lamda transform

```
import json
extracted_events = events.rdd.map(lambda x: json.loads(x.value)).toDF()
```

```
extracted_events.show()

```
 Following output is observed

```
+------+--------------+-----------+--------------+
|Accept|          Host| User-Agent|    event_type|
+------+--------------+-----------+--------------+
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_knife|
|   */*|localhost:5000|curl/7.47.0|purchase_knife|
|   */*|localhost:5000|curl/7.47.0|purchase_knife|
|   */*|localhost:5000|curl/7.47.0|purchase_knife|
|   */*|localhost:5000|curl/7.47.0|    join_guild|
|   */*|localhost:5000|curl/7.47.0|    join_guild|
|   */*|localhost:5000|curl/7.47.0|    join_guild|
|   */*|localhost:5000|curl/7.47.0|    join_guild|
|   */*|localhost:5000|curl/7.47.0|    join_guild|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
+------+--------------+-----------+--------------+
only showing top 20 rows

```
All extracted events we have put in temptable and not we can run spark SQL on it .
```
extracted_events.registerTempTable('temptable')
spark.sql("select * from temptable limit 10").show()

```

```
+------+--------------+-----------+--------------+
|Accept|          Host| User-Agent|    event_type|
+------+--------------+-----------+--------------+
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
+------+--------------+-----------+--------------+

```

We are running a SQL to find all transaction types grouped by even type.

```
spark.sql("select count(host),event_type from temptable group by event_type").show()

```

```
+-----------+--------------+                                                    
|count(host)|    event_type|
+-----------+--------------+
|          7|    join_guild|
|          5|purchase_sword|
|          5|purchase_knife|
|          6|       default|
+-----------+--------------+
```
Exit pyspark with:

```
exit()
```

Exit flask with:

```
control-C

```

## JUPITER NOTEBOOK with Pyspark

```
docker-compose exec spark \
  env \
    PYSPARK_DRIVER_PYTHON=jupyter \
    PYSPARK_DRIVER_PYTHON_OPTS='notebook --no-browser --port 8888 --ip 0.0.0.0 --allow-root' \
  pyspark
```
Same command in 1 line


```
docker-compose exec spark env PYSPARK_DRIVER_PYTHON=jupyter PYSPARK_DRIVER_PYTHON_OPTS='notebook --no-browser --port 8888 --ip 0.0.0.0 --allow-root' pyspark

```


```
science@w205s4-crook-9:~/w205/assignment-11-bhuvneshsharma$ docker-compose exec spark env PYSPARK_DRIVER_PYTHON=jupyter PYSPARK_DRIVER_PYTHON_OPTS='notebook --no-browser --port 8888 --ip 0.0.0.0 --allow-root' pyspark
[I 03:09:04.848 NotebookApp] Writing notebook server cookie secret to /root/.local/share/jupyter/runtime/notebook_cookie_secret
[I 03:09:04.904 NotebookApp] Serving notebooks from local directory: /spark-2.2.0-bin-hadoop2.6
[I 03:09:04.905 NotebookApp] 0 active kernels 
[I 03:09:04.905 NotebookApp] The Jupyter Notebook is running at: http://0.0.0.0:8888/?token=427cdd7798b7c90d002927739def32a60f7a3fa37d9f6589
[I 03:09:04.905 NotebookApp] Use Control-C to stop this server and shut down all kernels (twice to skip confirmation).
[C 03:09:04.906 NotebookApp] 
    
    Copy/paste this URL into your browser when you connect for the first time,
    to login with a token:
        http://0.0.0.0:8888/?token=427cdd7798b7c90d002927739def32a60f7a3fa37d9f6589


```

Replace the Ip with correct IP
```
http://138.68.44.59:8888/?token=427cdd7798b7c90d002927739def32a60f7a3fa37d9f6589
```



First exec a bash shell into the spark container:

```
docker-compose exec spark bash

```

Create a symbolic link from the spark directory to /w205 :

```
ln -s /w205 w205

```

Exit the container:

```
exit
```

Now you should see the w205 directory listed in the Jupyter Notebook directory structure.

As a side note, anytime I have a Jupyter Notebook directory and I'm not sure which directory I'm in, one easy way to just create an Python notebook and run some code cells to pull the current working directory.

If it's on a Linux based system, you can use the following code cell:

```
import os
os.getcwd()
!pwd
```

## JUPITER NOTEBOOK for EXTRACTING EVENTS

Following is the code added to extract_events.ipynb

Import pyspark and UDF

```
import json
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import udf
```

Build spark session

```
spark = SparkSession \
        .builder \
        .appName("ExtractEventsJob") \
        .getOrCreate()
```

Connect to Kafka session

```
raw_events = spark \
        .read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "events") \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()
```

Cast the raw events to string and then tranform them to Data frame.

```
events = raw_events.select(raw_events.value.cast('string'))
extracted_events = events.rdd.map(lambda x: json.loads(x.value)).toDF()

```

Write the events to HDFS

```
extracted_events \
        .write \
        .mode("overwrite") \
        .parquet("/tmp/extracted_events")
```


## JUPITER NOTEBOOK for TRANSFORMING EVENTS


Following is the code added to transform_events.ipynb

Import pyspark and UDF

```
import json
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import udf

```

This is where we adding additonal headers Host and Cache-Control

```
@udf('string')
def munge_event(event_as_json):
    event = json.loads(event_as_json)
    event['Host'] = "moe" # silly change to show it works
    event['Cache-Control'] = "no-cache"
    return json.dumps(event)
```

Build spark session

```
spark = SparkSession \
        .builder \
        .appName("TransformEventsJob") \
        .getOrCreate()
```

Connect to Kafka session

```
raw_events = spark \
        .read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "events") \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()

```

Show the raw events

```
raw_events.show()

```

```
+----+--------------------+------+---------+------+--------------------+-------------+
| key|               value| topic|partition|offset|           timestamp|timestampType|
+----+--------------------+------+---------+------+--------------------+-------------+
|null|[7B 22 48 6F 73 7...|events|        0|     0|2018-07-18 23:41:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     1|2018-07-18 23:41:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     2|2018-07-18 23:41:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     3|2018-07-18 23:41:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     4|2018-07-18 23:41:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     5|2018-07-18 23:41:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     6|2018-07-18 23:42:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     7|2018-07-18 23:42:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     8|2018-07-18 23:42:...|            0|
+----+--------------------+------+---------+------+--------------------+-------------+
```

Print Schema

```
raw_events.printSchema()

```

```
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)
```

Cast the raw events to string and then tranform them to Data frame.


```
munged_events = raw_events \
        .select(raw_events.value.cast('string').alias('raw'),
                raw_events.timestamp.cast('string')) \
        .withColumn('munged', munge_event('raw'))

```


```
    munged_events.show()
```

```
+--------------------+--------------------+--------------------+
|                 raw|           timestamp|              munged|
+--------------------+--------------------+--------------------+
|{"Host": "localho...|2018-07-18 23:41:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:41:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:41:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:41:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:41:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:41:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:42:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:42:...|{"Host": "moe", "...|
|{"Host": "localho...|2018-07-18 23:42:...|{"Host": "moe", "...|
+--------------------+--------------------+--------------------+
```

```
    munged_events.printSchema()
```

```
root
 |-- raw: string (nullable = true)
 |-- timestamp: string (nullable = true)
 |-- munged: string (nullable = true)
```

Cast the raw events to string and then tranform them to Data frame.


```
events = raw_events.select(raw_events.value.cast('string'))
extracted_events = events.rdd.map(lambda x: json.loads(x.value)).toDF()

```

```
+------+--------------+-----------+--------------+
|Accept|          Host| User-Agent|    event_type|
+------+--------------+-----------+--------------+
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|       default|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
|   */*|localhost:5000|curl/7.47.0|purchase_sword|
+------+--------------+-----------+--------------+
```

```
    extracted_events.printSchema()

```

```
root
 |-- Accept: string (nullable = true)
 |-- Host: string (nullable = true)
 |-- User-Agent: string (nullable = true)
 |-- event_type: string (nullable = true)

```

Write to HDFS

```
extracted_events \
        .write \
        .mode("overwrite") \
        .parquet("/tmp/sword_events")
```


## JUPITER NOTEBOOK for SEPARATING EVENTS

Following is the code added to transform_events.ipynb

Import pyspark and UDF

```
import json
from pyspark.sql import SparkSession, Row
from pyspark.sql.functions import udf
```

This is where we adding additonal headers Host and Cache-Control

```
@udf('string')
def munge_event(event_as_json):
    event = json.loads(event_as_json)
    event['Host'] = "BHUVNESH-MACHINE" # silly change to show it works
    event['Cache-Control'] = "no-cache"
    return json.dumps(event)
```
Build spark session

```
spark = SparkSession \
        .builder \
        .appName("SeparateEventsJob") \
        .getOrCreate()
```

Connect to Kafka session


```
 raw_events = spark \
        .read \
        .format("kafka") \
        .option("kafka.bootstrap.servers", "kafka:29092") \
        .option("subscribe", "events") \
        .option("startingOffsets", "earliest") \
        .option("endingOffsets", "latest") \
        .load()
```

Show raw events
```
raw_events.show()
```

```
+----+--------------------+------+---------+------+--------------------+-------------+
| key|               value| topic|partition|offset|           timestamp|timestampType|
+----+--------------------+------+---------+------+--------------------+-------------+
|null|[7B 22 48 6F 73 7...|events|        0|     0|2018-07-29 23:45:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     1|2018-07-29 23:45:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     2|2018-07-29 23:45:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     3|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     4|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     5|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     6|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     7|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     8|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|     9|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    10|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    11|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    12|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    13|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    14|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    15|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    16|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    17|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    18|2018-07-29 23:46:...|            0|
|null|[7B 22 48 6F 73 7...|events|        0|    19|2018-07-29 23:46:...|            0|
+----+--------------------+------+---------+------+--------------------+-------------+
```

```
raw_events.printSchema()

```

```
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)

```

```
munged_events = raw_events \
        .select(raw_events.value.cast('string').alias('raw'),
                raw_events.timestamp.cast('string')) \
        .withColumn('munged', munge_event('raw'))
```


```
    munged_events.show()
```

```
+--------------------+--------------------+--------------------+
|                 raw|           timestamp|              munged|
+--------------------+--------------------+--------------------+
|{"Host": "localho...|2018-07-29 23:45:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:45:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:45:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
|{"Host": "localho...|2018-07-29 23:46:...|{"Host": "BHUVNES...|
+--------------------+--------------------+--------------------+
```

```
    munged_events.printSchema()

```

```
root
 |-- raw: string (nullable = true)
 |-- timestamp: string (nullable = true)
 |-- munged: string (nullable = true)
```

```
extracted_events = munged_events \
        .rdd \
        .map(lambda r: Row(timestamp=r.timestamp, **json.loads(r.munged))) \
        .toDF()
    extracted_events.show()

```

```
+------+-------------+----------------+-----------+--------------+--------------------+
|Accept|Cache-Control|            Host| User-Agent|    event_type|           timestamp|
+------+-------------+----------------+-----------+--------------+--------------------+
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|       default|2018-07-29 23:45:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:45:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:45:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|    join_guild|2018-07-29 23:46:...|
+------+-------------+----------------+-----------+--------------+--------------------+
only showing top 20 rows
```

```
 sword_purchases = extracted_events \
        .filter(extracted_events.event_type == 'purchase_sword')

    sword_purchases.show()

```

```
+------+-------------+----------------+-----------+--------------+--------------------+
|Accept|Cache-Control|            Host| User-Agent|    event_type|           timestamp|
+------+-------------+----------------+-----------+--------------+--------------------+
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:45:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:45:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_sword|2018-07-29 23:46:...|
+------+-------------+----------------+-----------+--------------+--------------------+

```

```
default_hits = extracted_events \
        .filter(extracted_events.event_type == 'default')

    default_hits.show()

```

```
+------+-------------+----------------+-----------+----------+--------------------+
|Accept|Cache-Control|            Host| User-Agent|event_type|           timestamp|
+------+-------------+----------------+-----------+----------+--------------------+
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|   default|2018-07-29 23:45:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|   default|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|   default|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|   default|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|   default|2018-07-29 23:46:...|
+------+-------------+----------------+-----------+----------+--------------------+

```


```
knife_purchases = extracted_events \
        .filter(extracted_events.event_type == 'purchase_knife')
knife_purchases.show()
```

```
+------+-------------+----------------+-----------+--------------+--------------------+
|Accept|Cache-Control|            Host| User-Agent|    event_type|           timestamp|
+------+-------------+----------------+-----------+--------------+--------------------+
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|purchase_knife|2018-07-29 23:46:...|
+------+-------------+----------------+-----------+--------------+--------------------+
```

```
join_guild = extracted_events \
        .filter(extracted_events.event_type == 'join_guild')

join_guild.show()
```

```

+------+-------------+----------------+-----------+----------+--------------------+
|Accept|Cache-Control|            Host| User-Agent|event_type|           timestamp|
+------+-------------+----------------+-----------+----------+--------------------+
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
|   */*|     no-cache|BHUVNESH-MACHINE|curl/7.47.0|join_guild|2018-07-29 23:46:...|
+------+-------------+----------------+-----------+----------+--------------------+
```

## ADDTIONAL PARAMETERS sent for Analytics and use for mobile app

We are exploring sending more parameters which can captured from the game and sent to the server. Below is an example where following parameters
location
discount
age

NOTE : WE are hard coding the variables  and sending ... these parameters can captured from different sources and updated in KAFKA message.



```
vi game_api_with_extended_json_events_discount.py
```

```python
#!/usr/bin/env python
import json
from kafka import KafkaProducer
from flask import Flask, request

app = Flask(__name__)
producer = KafkaProducer(bootstrap_servers='kafka:29092')


def log_to_kafka(topic, event):
    event.update(request.headers)
    producer.send(topic, json.dumps(event).encode())
    print event


@app.route("/")
def default_response():
    default_event = {'event_type': 'default','discount':'10%','location':'US','age':'10'}
    log_to_kafka('events', default_event)
    return "\nThis is the default response!\n"

@app.route("/purchase_a_sword")
def purchase_a_sword():
    purchase_sword_event = {'event_type': 'purchase_sword','discount':'20%','location':'INDIA','age':'25'}
    log_to_kafka('events', purchase_sword_event)
    return "\nSword Purchased!\n"

@app.route("/purchase_a_knife")
def purchase_a_knife():
    # business logic to purchase knife
    # log event to kafka
    purchase_knife_event = {'event_type': 'purchase_knife','discount':'30%','location':'CANADA','age':'30'}
    log_to_kafka('events', purchase_knife_event)
    return "\nKnife Purchased!\n"

@app.route("/join_a_guild")
def join_guild():
    # business logic to purchase sword
    # log event to kafka
    join_guild_event = {'event_type': 'join_guild','discount':'50%','location':'UK','age':'20'}
    log_to_kafka('events', join_guild_event)
    return "\nGuild Joined!\n"

```

Follow the steps which have been followed with running the flask and performing transactions via curl

```
docker-compose exec mids env FLASK_APP=/w205/assignment-11-bhuvneshsharma/game_api_with_extended_json_events_discount.py flask run
```

Following output is recieved after curl transactions

```
 * Serving Flask app "game_api_with_extended_json_events_discount"
 * Running on http://127.0.0.1:5000/ (Press CTRL+C to quit)
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:20:24] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:20:59] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:21:00] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:21:03] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:21:04] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:21:05] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'join_guild', 'age': '20', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '50%', 'Host': u'localhost:5000', 'location': 'UK'}
127.0.0.1 - - [23/Jul/2018 04:21:06] "GET /join_a_guild HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:20] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:25] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:26] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:26] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:27] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:27] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:28] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_knife', 'age': '30', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '30%', 'Host': u'localhost:5000', 'location': 'CANADA'}
127.0.0.1 - - [23/Jul/2018 04:21:28] "GET /purchase_a_knife HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:33] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:34] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:34] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:35] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:35] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'purchase_sword', 'age': '25', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '20%', 'Host': u'localhost:5000', 'location': 'INDIA'}
127.0.0.1 - - [23/Jul/2018 04:21:36] "GET /purchase_a_sword HTTP/1.1" 200 -
{'event_type': 'default', 'age': '10', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '10%', 'Host': u'localhost:5000', 'location': 'US'}
127.0.0.1 - - [23/Jul/2018 04:21:40] "GET / HTTP/1.1" 200 -
{'event_type': 'default', 'age': '10', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '10%', 'Host': u'localhost:5000', 'location': 'US'}
127.0.0.1 - - [23/Jul/2018 04:21:41] "GET / HTTP/1.1" 200 -
{'event_type': 'default', 'age': '10', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '10%', 'Host': u'localhost:5000', 'location': 'US'}
127.0.0.1 - - [23/Jul/2018 04:21:41] "GET / HTTP/1.1" 200 -
{'event_type': 'default', 'age': '10', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '10%', 'Host': u'localhost:5000', 'location': 'US'}
127.0.0.1 - - [23/Jul/2018 04:21:42] "GET / HTTP/1.1" 200 -
{'event_type': 'default', 'age': '10', 'Accept': u'*/*', 'User-Agent': u'curl/7.47.0', 'discount': '10%', 'Host': u'localhost:5000', 'location': 'US'}
127.0.0.1 - - [23/Jul/2018 04:21:44] "GET / HTTP/1.1" 200 -

```

output of the print enabled on flask

```
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "join_guild", "age": "20", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "50%", "Host": "localhost:5000", "location": "UK"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_knife", "age": "30", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "30%", "Host": "localhost:5000", "location": "CANADA"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "purchase_sword", "age": "25", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "20%", "Host": "localhost:5000", "location": "INDIA"}
{"event_type": "default", "age": "10", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "10%", "Host": "localhost:5000", "location": "US"}
{"event_type": "default", "age": "10", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "10%", "Host": "localhost:5000", "location": "US"}
{"event_type": "default", "age": "10", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "10%", "Host": "localhost:5000", "location": "US"}
{"event_type": "default", "age": "10", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "10%", "Host": "localhost:5000", "location": "US"}
{"event_type": "default", "age": "10", "Accept": "*/*", "User-Agent": "curl/7.47.0", "discount": "10%", "Host": "localhost:5000", "location": "US"}
```


Follow the steps on pyspark a perform the steps done earlier and the output of the extracted events show is the following

```
+------+--------------+-----------+---+--------+--------------+--------+
|Accept|          Host| User-Agent|age|discount|    event_type|location|
+------+--------------+-----------+---+--------+--------------+--------+
|   */*|localhost:5000|curl/7.47.0| 10|     10%|       default|      US|
|   */*|localhost:5000|curl/7.47.0| 25|     20%|purchase_sword|   INDIA|
|   */*|localhost:5000|curl/7.47.0| 25|     20%|purchase_sword|   INDIA|
|   */*|localhost:5000|curl/7.47.0| 25|     20%|purchase_sword|   INDIA|
|   */*|localhost:5000|curl/7.47.0| 25|     20%|purchase_sword|   INDIA|
|   */*|localhost:5000|curl/7.47.0| 25|     20%|purchase_sword|   INDIA|
|   */*|localhost:5000|curl/7.47.0| 30|     30%|purchase_knife|  CANADA|
|   */*|localhost:5000|curl/7.47.0| 30|     30%|purchase_knife|  CANADA|
|   */*|localhost:5000|curl/7.47.0| 30|     30%|purchase_knife|  CANADA|
|   */*|localhost:5000|curl/7.47.0| 30|     30%|purchase_knife|  CANADA|
|   */*|localhost:5000|curl/7.47.0| 30|     30%|purchase_knife|  CANADA|
|   */*|localhost:5000|curl/7.47.0| 20|     50%|    join_guild|      UK|
|   */*|localhost:5000|curl/7.47.0| 20|     50%|    join_guild|      UK|
|   */*|localhost:5000|curl/7.47.0| 20|     50%|    join_guild|      UK|
|   */*|localhost:5000|curl/7.47.0| 20|     50%|    join_guild|      UK|
|   */*|localhost:5000|curl/7.47.0| 10|     10%|       default|      US|
|   */*|localhost:5000|curl/7.47.0| 10|     10%|       default|      US|
|   */*|localhost:5000|curl/7.47.0| 10|     10%|       default|      US|
|   */*|localhost:5000|curl/7.47.0| 10|     10%|       default|      US|
|   */*|localhost:5000|curl/7.47.0| 10|     10%|       default|      US|
+------+--------------+-----------+---+--------+--------------+--------+
```

Run the SQL command to get all transactions grouped via event_type , discount ,location , age

```
spark.sql("select count(host),event_type,discount,location,age from temptable group by event_type , discount ,location , age").show()
```

```
+-----------+--------------+--------+--------+---+
|count(host)|    event_type|discount|location|age|
+-----------+--------------+--------+--------+---+
|          4|    join_guild|     50%|      UK| 20|
|          5|purchase_knife|     30%|  CANADA| 30|
|          5|purchase_sword|     20%|   INDIA| 25|
|          6|       default|     10%|      US| 10|
+-----------+--------------+--------+--------+---+
```


## Tear down the cluster:

```
docker-compose down
```

All 3 containers should be shutdown with the following output.

```
Stopping assignment11bhuvneshsharma_kafka_1 ... done
Stopping assignment11bhuvneshsharma_spark_1 ... done
Stopping assignment11bhuvneshsharma_mids_1 ... done
Stopping assignment11bhuvneshsharma_zookeeper_1 ... done
Stopping assignment11bhuvneshsharma_cloudera_1 ... done
Removing assignment11bhuvneshsharma_kafka_1 ... done
Removing assignment11bhuvneshsharma_spark_1 ... done
Removing assignment11bhuvneshsharma_mids_1 ... done
Removing assignment11bhuvneshsharma_zookeeper_1 ... done
Removing assignment11bhuvneshsharma_cloudera_1 ... done
Removing network assignment11bhuvneshsharma_default

```

Verify that the cluster is properly down:


```
docker ps -a
```

Following output should be noticed.
```
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES

```

```
docker-compose ps
```


```
Name   Command   State   Ports 
------------------------------
```

## Learnings
Created an Architecture where we can have created set up where we have messaging system based on KAFKA which is integrated with events which are triggered by web events. We created docker containers of zookeeper , kafka and mids.
We learnt how to set up a FLASK server on the MIDS container. FLASK server was provided different configurations which included 
- Providing default response.
- Integrate with KAFKA topic.
- create various python files which can be used for starting a webserver like FLASK.
- Configure python such that on different events we can publish data to different kafka queues.
- Read the kafka queue via different methods
	- PYSPARK
	- JUPITER
	- SPARK SQL
- Publish data to HDFS for future usage.

We also learnt that even though FLASK is light weight web server which integrates with python easily but is generally not preferred in high traffic production applications. One of the other key learnings from the assignment was the ability to integrate python code with webserver in its configuration.

We learnt how to use CURL to simulate http requests on a particular website. We learnt how to configure docker-compose yml file to connect zookeeper and kafka and mids.
We created an multiple containers using the file system which is on the droplet given by berkeley mids program.We also learnt to create a messaging topic on the kafka system.

### FLASK Config
 We learnt how to configure flask with startup python file. From the python file we integrated the KAFKA system for events tracking. We also created a message subcribtion to read those messages real time.

The low latency and an easy-to-use event time support also apply to Kafka Streams. It is a rather focused library, and it’s very well-suited for certain types of tasks. That’s also why some of its design can be so optimized for how Kafka works. And if you need to do a simple Kafka topic-to-topic transformation, count elements by key, enrich a stream with data from another topic, or run an aggregation or only real-time processing — Kafka Streams is for you.

If event time is not relevant and latencies in the seconds range are acceptable, Spark is the first choice. It is stable and almost any type of system can be easily integrated. In addition it comes with every Hadoop distribution. Furthermore, the code used for batch applications can also be used for the streaming applications as the API is the same.


## Future
- Read individual elements of the individual records from Kafka messaging system and use it for analytics
- Real time enable publishing of records from a web application.
- Use spark system to run real time analytics on massively parallely system.
- Create Analytics application which can processes large amount user data.
- Integrate with HDFS and other database systems
- Create Analytics prediction on the probability that which event a user is most likely to purchase.
- Create Analytics solutions.
- Improve broker architecture.
- Explore PYSPARK to subscribe and read messages created by FLASK set up and posted to KAFKA.
- Explore python by reading messages and parsing it and finally performing analytics on it.
- Use spark to transform the messages.
- Use spark sql to access data from JSON.
- Use HDFS to store the web trends and analytics data.


## Future ideas for the Application.

Following possible areas we can develop the mobile application using the web trend data.
- If a user purchases a sword , we can run analytics to provide in game discount based on some business logic.
- We can provide analytics around who are the users friends which purchased a sword , knife or joined a guild.
- We can provide real time analytics to the user which triggers the events around probability of winning if in app purchase is done.
- We can analyze web events and correlate the events to in app purchases to identify the most purchased event.
- Corelate the event with purchase history so that we can analyze purchase history and event with 
 - location of the user
 - Demography
 - Age
 - Number of levels crossed
 - Time of day
 - Skill level of the player.
 - Others.

Kafka brokers process records organized into topics. A topic is a category of records that share similar characteristics. For example, a topic might consist of instant messages from social media or navigation information for users on a web site. Each topic has a unique corresponding table in data storage.

A producer is an external process that sends records to a Kafka topic. A consumer is an external process that receives topic streams from a Kafka cluster.

![ALT TEXT](https://www.cloudera.com/documentation/kafka/latest/images/xtopic_producer_consumer.png.pagespeed.ic.gpLmxxi15Q.webp)

While these illustrations show single instances of the components of a Kafka implementation, Kafka brokers typically host multiple partitions and replicas, with any number of producers and consumers, up to the requirements and limits of the deployed system.
![ALT TEXT](https://www.cloudera.com/documentation/kafka/latest/images/many_to_many.png)

