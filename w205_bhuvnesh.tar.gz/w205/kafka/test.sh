which kafkacat
pwd
cd /w205/kafka/
