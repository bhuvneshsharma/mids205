# Bhuvnesh Sharma made changes as part of the assignment
# template-activity-01

## Assignment 01: Set up and prerequisites

1. Git
- Install git.
https://git-scm.com/downloads

- You may see references to the stand alone app for git on your desktop. That's not what we're using for this course.

- Watch the videos in this series that you need to watch (seriously, even if you've been working with git for a while, it's sometimes handy to revisit, e.g., the difference between git and Github). They are on youtube. If you don't have a subscription, it will pop up with short ads. Sorry, but these are really decent videos. There's about 30 min total.

https://www.youtube.com/playlist?list=PL5-da3qGB5IBLMp7LtN8Nc3Efd4hJq0kD

- Follow the instructions to do what the videos walk you through. 



2. Data Engineering Jobs

- Google "data engineering jobs"
- Read ads (between 5&10)
- What are companies looking for in skills, experience, competencies?
  * Answer: The companies are looking for following Skills , experience and competencies

	* Skills
	R , Python , Kafka, Flink, Kinesis, Spark, Storm , Django
	*  Experience
	10 years experience
	SW industry experience

	* Compentencies
	Good communication skills
	Good business and digital skills




3. Submit a PR for this assignment.
- You changed this `README.md` in part 2;

- Commit your changes.

- Submit a PR with this `README.md` changed.
(following the instructions from the synchronous session)
