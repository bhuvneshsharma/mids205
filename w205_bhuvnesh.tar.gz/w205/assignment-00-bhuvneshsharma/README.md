# Welcome to MIDS w205 - Fundamentals of Data Engineering!

- To get going, click the assignment link posted to your section's Wall.

- You will be asked to login or sign up for github.

- Once you do, you'll see a webpage where you select your name from a list. 

- That's it. 

Bhuvnesh made changes to this ... 
