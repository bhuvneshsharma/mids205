
# Query Project
- In the Query Project, you will get practice with SQL while learning about Google Cloud Platform (GCP) and BiqQuery. You'll answer business-driven questions using public datasets housed in GCP. To give you experience with different ways to use those datasets, you will use the web UI (BiqQuery) and the command-line tools, and work with them in jupyter notebooks.
- We will be using the Bay Area Bike Share Trips Data (https://cloud.google.com/bigquery/public-data/bay-bike-share). 

#### Query Project Problem Statement
- You're a data scientist at Ford GoBike (https://www.fordgobike.com/), the company running Bay Area Bikeshare. You are trying to increase ridership, and you want to offer deals through the mobile app to do so. What deals do you offer though? Currently, your company has three options: a flat price for a single one-way trip, a day pass that allows unlimited 30-minute rides for 24 hours and an annual membership. 

- Through this project, you will answer these questions: 
  * What are the 5 most popular trips that you would call "commuter trips"?
  * What are your recommendations for offers (justify based on your findings)?

_______________________________________________________________________________________________________________


## Assignment 04 - Querying data - Answer Your Project Questions

### Your Project Questions

- Answer at least 4 of the questions you identified last week.
- You can use either BigQuery or the bq command line tool.
- Paste your questions, queries and answers below.

- Question 1: What is most popular bike across all routes and also find the duration of the bike commute time.
  * Answer:

| FREQUENCY | bike_number | SECONDS |
------------|-------------|---------|
|      2872 |         389 | 2711439 |
|      2853 |         392 | 2530024 |
|      2853 |         524 | 2984643 |
|      2845 |         503 | 2821083 |
|      2827 |         328 | 2511687 |
|      2823 |         415 | 2999013 |
|      2822 |         558 | 2495749 |
|      2821 |         585 | 2346656 |
|      2821 |         631 | 2632027 |
|      2818 |         463 | 2344559 |

  * SQL query:

```sql
#standardSQL
SELECT
  COUNT( bike_number ) FREQUENCY , bike_number , sum( duration_sec ) SECONDS
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY  bike_number
ORDER BY FREQUENCY DESC
LIMIT 10
```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
#standardSQL
SELECT
  COUNT( bike_number ) FREQUENCY , bike_number , sum( duration_sec ) SECONDS
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY  bike_number
ORDER BY FREQUENCY DESC
LIMIT 10
'

- Question 2: Top 10 Stations which run out of bikes most frequently ?

  * Answer:

NOBIKES|bikes_available|name|dockcount
-------|---------------|-----|--------
   44844 |               0 | 2nd at Folsom                            |        19 |
   44728 |               0 | Commercial at Montgomery                 |        15 |
   35903 |               0 | Embarcadero at Vallejo                   |        15 |
   32980 |               0 | Embarcadero at Sansome                   |        15 |
   32505 |               0 | Clay at Battery                          |        15 |
   32027 |               0 | San Francisco Caltrain (Townsend at 4th) |        19 |
   31733 |               0 | Grant Avenue at Columbus Avenue          |        19 |
   30800 |               0 | Market at 4th                            |        19 |
   27938 |               0 | Howard at 2nd                            |        19 |
   25496 |               0 | Broadway St at Battery St                |        15 |

  * SQL query:

```sql
#standardSQL
SELECT
  BIKE_STATUS.NOBIKES,
  BIKE_STATUS.bikes_available,
  name,
  dockcount
FROM
  `bigquery-public-data.san_francisco.bikeshare_stations` bikeshare_stations
JOIN (
  SELECT
    COUNT(station_id) AS NOBIKES,
    station_id AS STATION_ID,
    bikes_available
  FROM
    `bigquery-public-data.san_francisco.bikeshare_status`
  WHERE
    bikes_available=0
  GROUP BY
    station_id,
    bikes_available ) BIKE_STATUS
ON
  bikeshare_stations.station_id=BIKE_STATUS.STATION_ID
WHERE
  BIKE_STATUS.NOBIKES > 10000
ORDER BY
  BIKE_STATUS.NOBIKES DESC
LIMIT
  10

```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
#standardSQL
SELECT
  BIKE_STATUS.NOBIKES,
  BIKE_STATUS.bikes_available,
  name,
  dockcount
FROM
  `bigquery-public-data.san_francisco.bikeshare_stations` bikeshare_stations
JOIN (
  SELECT
    COUNT(station_id) AS NOBIKES,
    station_id AS STATION_ID,
    bikes_available
  FROM
    `bigquery-public-data.san_francisco.bikeshare_status`
  WHERE
    bikes_available=0
  GROUP BY
    station_id,
    bikes_available ) BIKE_STATUS
ON
  bikeshare_stations.station_id=BIKE_STATUS.STATION_ID
WHERE
  BIKE_STATUS.NOBIKES > 10000
ORDER BY
  BIKE_STATUS.NOBIKES DESC
LIMIT
  10'

- Question 3: What are the most popular zip codes entered by the users
  * Answer:

FREQUENCY | zip_code
----------|--------
    106913 | 94107    
     61232 | 94105    
     46544 | 94133    
     38072 | 94103    
     33642 | 94111    
     30222 | 94102    
     19043 | 94109    
     15420 | 95112    
     15385 | nil      
     13673 | 94158

  * SQL query:

```sql
#standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  zip_code
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  zip_code
ORDER BY
  FREQUENCY DESC
LIMIT
  10
```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
#standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY,
  zip_code
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY
  zip_code
ORDER BY
  FREQUENCY DESC
LIMIT
  10
'

- Question 4: Find out which station runs out of bikes and in which hour of the day. Limit this analysis for the stations which have more than 20000 instances when bikes were not there.
  * Answer:

| FREQUENCY | STATION_ID | HOUROFTHEDAY |
------------|------------|--------------|
|      3216 |         45 |            6 |
|       786 |         65 |            6 |
|       853 |         56 |            6 |
|      1658 |         60 |            6 |
|      1151 |         63 |            6 |
|       879 |         73 |            6 |
|       641 |         82 |            6 |
|       968 |         32 |            6 |
|      3168 |         41 |            6 |
|       778 |         64 |            6 |
|       422 |         71 |            6 |
|         8 |         70 |            6 |
|      1435 |         48 |            6 |
|      2096 |         76 |            6 |
|      2786 |         62 |            6 |
|      1631 |         41 |            7 |
|      1080 |         63 |            7 |
|       108 |         69 |            7 |
|       141 |         54 |            7 |
|       981 |         64 |            7 |
|      1731 |         65 |            7 |
|      2343 |         45 |            7 |
|      1192 |         73 |            7 |
|      1500 |         32 |            7 |
|      2400 |         62 |            7 |
|       792 |         71 |            7 |
|       523 |         70 |            7 |
|       700 |         76 |            7 |
|      2370 |         82 |            7 |
|      3266 |         48 |            7 |
|       259 |         56 |            7 |
|      3981 |         60 |            7 |
|      5366 |         70 |            8 |
|       117 |         56 |            8 |
|       765 |         45 |            8 |
|      1195 |         65 |            8 |
|      1720 |         82 |            8 |
|       477 |         76 |            8 |
|      1846 |         60 |            8 |
|       738 |         48 |            8 |
|      4537 |         73 |            8 |
|      1728 |         62 |            8 |
|       247 |         63 |            8 |
|      1652 |         32 |            8 |
|      1830 |         69 |            8 |
|      2447 |         54 |            8 |
|       379 |         41 |            8 |
|      1884 |         71 |            8 |
|       294 |         48 |            9 |
|       243 |         64 |            9 |
|     11131 |         70 |            9 |
|       559 |         32 |            9 |
|      1647 |         62 |            9 |
|        60 |         63 |            9 |
|       191 |         76 |            9 |
|       418 |         60 |            9 |
|      5646 |         69 |            9 |
|      6655 |         54 |            9 |
|      3946 |         71 |            9 |
|       364 |         82 |            9 |
|       124 |         41 |            9 |
|       315 |         65 |            9 |
|      1691 |         56 |            9 |
|      6969 |         73 |            9 |
|      4999 |         73 |           10 |
|      2363 |         69 |           10 |
|      3828 |         71 |           10 |
|       112 |         41 |           10 |
|        34 |         45 |           10 |
|      4976 |         54 |           10 |
|      1643 |         56 |           10 |
|        59 |         48 |           10 |
|       268 |         32 |           10 |
|        75 |         65 |           10 |
|        91 |         82 |           10 |
|        57 |         63 |           10 |
|       400 |         60 |           10 |
|       152 |         64 |           10 |
|      6065 |         70 |           10 |
|       188 |         76 |           10 |
|        96 |         82 |           11 |
|       209 |         32 |           11 |
|        24 |         64 |           11 |
|       202 |         65 |           11 |
|      1962 |         69 |           11 |
|       508 |         62 |           11 |
|       335 |         76 |           11 |
|      4303 |         70 |           11 |
|       173 |         41 |           11 |
|      2051 |         54 |           11 |
|        65 |         63 |           11 |
|      2351 |         71 |           11 |
|        63 |         45 |           11 |
|      2384 |         73 |           11 |
|      1029 |         56 |           11 |
|     64263 |         24 |           16 |
|     51322 |         83 |           16 |
|     56448 |         82 |           16 |
|     64432 |         23 |           16 |
|     51927 |         84 |           16 |


  * SQL query:
```sql
#standardSQL
SELECT
  COUNT(station_id) FREQUENCY,
  station_id STATION_ID,
  EXTRACT(HOUR
  FROM
    time) HOUROFTHEDAY
FROM
  `bigquery-public-data.san_francisco.bikeshare_status`
WHERE
  bikes_available=0
  AND station_id IN (
  SELECT
    bikeshare_stations.station_id
  FROM
    `bigquery-public-data.san_francisco.bikeshare_stations` bikeshare_stations
  JOIN (
    SELECT
      COUNT(station_id) AS NOBIKES,
      station_id,
      bikes_available
    FROM
      `bigquery-public-data.san_francisco.bikeshare_status`
    WHERE
      bikes_available=0
    GROUP BY
      station_id,
      bikes_available ) BIKE_STATUS
  ON
    bikeshare_stations.station_id=BIKE_STATUS.STATION_ID
  WHERE
    BIKE_STATUS.NOBIKES > 20000 )
  AND (EXTRACT(HOUR
    FROM
      time)>5
    AND EXTRACT(HOUR
    FROM
      time)<=11)
  OR (EXTRACT(HOUR
    FROM
      time)>15
    AND EXTRACT(HOUR
    FROM
      time)<=21)
GROUP BY
  EXTRACT(HOUR
  FROM
    time),
  station_id

```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
#standardSQL
SELECT
  COUNT(station_id) FREQUENCY,
  station_id STATION_ID,
  EXTRACT(HOUR
  FROM
    time) HOUROFTHEDAY
FROM
  `bigquery-public-data.san_francisco.bikeshare_status`
WHERE
  bikes_available=0
  AND station_id IN (
  SELECT
    bikeshare_stations.station_id
  FROM
    `bigquery-public-data.san_francisco.bikeshare_stations` bikeshare_stations
  JOIN (
    SELECT
      COUNT(station_id) AS NOBIKES,
      station_id,
      bikes_available
    FROM
      `bigquery-public-data.san_francisco.bikeshare_status`
    WHERE
      bikes_available=0
    GROUP BY
      station_id,
      bikes_available ) BIKE_STATUS
  ON
    bikeshare_stations.station_id=BIKE_STATUS.STATION_ID
  WHERE
    BIKE_STATUS.NOBIKES > 20000 )
  AND (EXTRACT(HOUR
    FROM
      time)>5
    AND EXTRACT(HOUR
    FROM
      time)<=11)
  OR (EXTRACT(HOUR
    FROM
      time)>15
    AND EXTRACT(HOUR
    FROM
      time)<=21)
GROUP BY
  EXTRACT(HOUR
  FROM
    time),
  station_id'



- Question 5: What is the cummulative commute time between different customer types.
  * Answer:

| FREQUENCY | subscriber_type |  SECONDS  |
+-----------+-----------------+-----------+
|    846839 | Subscriber      | 493507486 |
|    136809 | Customer        | 508763279 |

  * SQL query:

```sql
#standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY , subscriber_type , sum( duration_sec ) SECONDS
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY subscriber_type
ORDER BY FREQUENCY DESC

```

GOOGLE BIGQUERY

bq query --use_legacy_sql=false '
#standardSQL
SELECT
  COUNT( trip_id ) FREQUENCY , subscriber_type , sum( duration_sec ) SECONDS
FROM
  `bigquery-public-data.san_francisco.bikeshare_trips`
GROUP BY subscriber_type
ORDER BY FREQUENCY DESC
'

