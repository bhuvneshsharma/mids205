# My annotations, Assignment 6


## Here I'm opening the directory that has my docker-compose file in it.
  501  cd w205/kafka-with-json/

## Next, I'm checking what's in my directory.
  502  ls

## Here I'm getting the data.
  505      curl -L -o github-example-large.json https://goo.gl/Hr6erG

## I'm spinning up my kafka, zookeeper, mids cluster.
  507  docker-compose up -d

## etc until you take down the cluster...
