---
title: "Assignment 06 for W205 by Bhuvnesh Sharma"
author: "Bhuvnesh Sharma"

---



#  Assignment 6 from Bhuvnesh Sharma for W205

## Executive Summary
	
	In the age of cloud computing , we are exploring new architecture of managed services architectures. Infrastructure services like docker have containerized the application architectures. In this assignment we would explore how web based application can exchange data in JSON format . This data can be continously streamed in JSON format to data services.
This data services can we real time data publish subscribe services based on KAFKA. The application gets data from student trying an exam and question attempts. This data can be real time feed into fast , scalable , durable and fault tolerant messaging system. This model can be used to create multiple applications.

## Approach

We would be following approach

- Login to the droplet
- cd to the drive where assignment 06
- Download the json file using curl
- Configure docker-compose yml file
- explain the YML and different pieces of architecture.
- Begin docker
- Create topic and then stream messages.
- Subscribe for messages.
- Shutdown the docker.

	We are planning to login to the machine where my student droplet has been configured. From that droplet machine we will spin up a cluster with kafka, zookeeper, and the mids container within Docker.
	Explore the different configurations of the the docker , kafka ,  zookeeper and mids. Then our goal is to stream messages to topics

### Login to the droplet

Using the account provided by MIDS program login to the droplet

#### Check the directory

```
pwd

cd w205
pwd

```

The result should be as below

/home/science/
/home/science/w205


### Clone the repository from github

Connect to github using git utility and clone the assignment 06

```
git clone https://github.com/mids-w205-crook/assignment-06-bhuvneshsharma.git

```

#### Move in the directory for the assignment


```
cd /home/science/w205/assignment-06-bhuvneshsharma

```

#### List down all the contents of the directory using following command

```
ls -lrt
```

#### Get the data from the location given the json file using the curl command.

Download the data file from the prescribed location. The json file once downloaded we need to explore the file.

The options -L for curl is to get the file from the location defined by the http location. 
-o option downloads the file with file name instead of putting in stdout.

```
curl -L -o assessment-attempts-20180128-121051-nested.json https://goo.gl/f5bRm4

```

#### list down the files in directory again
To confirm that file assessment-attempts-20180128-121051-nested.json has been downloaded from the location https://goo.gl/f5bRm4 run the following command.


```
ls -lrt
```
We see the following output , which confirms that the file is downloaded correctly.

-rw-rw-r-- 1 science science 9315053 Jun 25 01:30 assessment-attempts-20180128-121051-nested.json

#### Explore the JSON file

We would explore the JSON file to better understand the data file.

```
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
more /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
tail -f /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
head -10  /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
```

JSON file appears to be machine readable file and hence it does not have spaces. We would have to use other tools to better explore the file.
We will be using jq command line utility to better understand the JSON.


```
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq .
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq  '.[0]'
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[0] | {sequences:}'
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort 
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr
cat /home/science/w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr | head -10

```

jq is command line tool that helps to better understand the json output from machine readable to human readable. Machine readable JSON output is typically created by web applications and hence to save size of packets all spaces are removed.

Output of the one of the command should be similar to the output below

```
      {
        "user_incomplete": false,
        "user_correct": true,
        "options": [
          {
            "checked": false,
            "id": "59b9fc4b-f239-4850-b1f9-912d1fd3ca13"
          },
          {
            "checked": false,
            "id": "2c29e8e8-d4a8-406e-9cdf-de28ec5890fe"
          },
          {
            "checked": false,
            "id": "62feee6e-9b76-4123-bd9e-c0b35126b1f1"
          },
          {
            "checked": true,
            "at": "2018-01-23T14:24:00.807Z",
            "id": "7f13df9c-fcbe-4424-914f-2206f106765c",
            "submitted": 1,
            "correct": true
          }
        ],
        "user_submitted": true,
        "id": "95194331-ac43-454e-83de-ea8913067055",
        "user_result": "correct"
      }
    ],
    "attempt": 1,
    "id": "5b28a462-7a3b-42e0-b508-09f3906d1703",
    "counts": {
      "incomplete": 1,
      "submitted": 4,
      "incorrect": 1,
      "all_correct": false,
      "correct": 2,
      "total": 4,
      "unanswered": 0
    }
  }
}
```


## create a docker yml file

Move the assignment directory and make the docker-compose.yml file.

```
cd /home/science/w205/assignment-06-bhuvneshsharma

vi docker-compose.yml

```

Insert the following code to the YML file and save it.


```
---
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"
    #ports:
      #- "32181:32181"
    extra_hosts:
      - "moby:127.0.0.1"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    volumes:
      - /home/science/w205:/w205
    expose:
      - "9092"
      - "29092"
    extra_hosts:
      - "moby:127.0.0.1"

  mids:
    image: midsw205/base:latest
    stdin_open: true
    tty: true
    volumes:
      - /home/science/w205:/w205
    extra_hosts:
      - "moby:127.0.0.1"


```
## Understanding docker-compose.yml

The docker-compose.yml is configuring 3 different containers within the cluster. The containers in the cluster are the following
- zookeeper
- kafka
- mids


### 1) zookeeper
	ZooKeeper is a centralized service for maintaining configuration information, naming, providing distributed synchronization, and providing group services. Zookeeper is distributed systems configuration management tool. Zookeeper provides multiple features for distributed applications like distributed configuration management, leader election, consensus handling, coordination and locks etc.
Zookeeper storing its data on tree like structure. It introduced as Data Treeand nodes introduced as zNodes. Zookeeper follows standard unix notations for file paths. For an example /A/B/C denote the path to zNode C, where Chas B as its parent and B has A as its parent.

##### image: confluentinc/cp-zookeeper:latest 
	This is from where we need to get the configuration of zookeeper. Also the setting is specifing that we need to get the latest configuration.
	If configured as following confluentinc/cp-zookeeper:4.0.0 , then it is pointing to use the version 4.0.0

##### ZOOKEEPER_CLIENT_PORT
	ZOOKEEPER_CLIENT_PORT: 32181
	ZOOKEEPER_TICK_TIME: 2000
	
	ZOOKEEPER_CLIENT_PORT is the port on which we are configuring zookeeper , port configured is 32181. ZooKeeper where to listen for connections by clien		ts such as Kafka
	
##### expose
	These are the ports which are opened


### 2) kafka
	Kafka is Fast, Scalable, Durable, and Fault-Tolerant publish-subscribe messaging system which can be used to real time data streaming. We can introduce Kafka as Distributed Commit Log which follows publish subscribe architecture. Like many publish-subscribe messaging systems, Kafka maintains feeds of messages in topics. Producers write data to topics and consumers read from topics. Since Kafka is a distributed system, topics are partitioned and replicated across multiple nodes.
	Messages in Kafka are simple byte arrays(String , JSON etc). When publishing, message can be attached to a key. Producer distributes all the messages with same key into same partition.

Kafka uses Zookeeper to mange following tasks
	* Electing a controller - The controller is one of the brokers and is responsible for maintaining the leader/follower relationship for all the partitions. When a node shuts down, it is the controller that tells other replicas to become partition leaders to replace the partition leaders on the node that is going away. Zookeeper is used to elect a controller, make sure there is only one and elect a new one it if it crashes.
	* Cluster membership - Which brokers are alive and part of the cluster? this is also managed through ZooKeeper.
	* Topic configuration - Which topics exist, how many partitions each has, where are the replicas, who is the preferred leader, what configuration overrides are set for each topic
	* Manage Quotas - How much data is each client allowed to read and write
	* Access control - Who is allowed to read and write to which topic (old high level consumer). Which consumer groups exist, who are their members and what is the latest offset each group got from each partition


##### image: confluentinc/cp-kafka:latest
        This is from where we need to get the configuration of kafka. Also the setting is specifing that we need to get the latest configuration.
        If configured as following confluentinc/cp-kafka:4.0.0 , then it is pointing to use the version 4.0.0

##### depends_on
	This configuration requests points to that the fact that this container of kafka depends on zookeeper container.
    
##### KAFKA_ZOOKEEPER_CONNECT
	Connects to zookeeper container at port 32181	
##### KAFKA_ADVERTISED_LISTENERS 
	Advertised listeners is required for starting up the Docker image because it is important to think through how other clients are going to connect to kafka. In a Docker environment, you will need to make sure that your clients can connect to Kafka and other services. Advertised listeners is how it gives out a host name that can be reached by the client.
	      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092

##### KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR
	This is needed when you are running with a single-node cluster. If you have three or more nodes, you do not need to change this from the default. Current setting is 1.

#####    volumes:
     	Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

#####    expose:
     	These are the ports which are exposed.
	 - "9092"
	 - "29092"
#####	extra_hosts:
	This is moby network which is getting mapped to 127.0.0.1
	- "moby:127.0.0.1"

### 3) mids
        
#####     image: midsw205/base:latest
	This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the latest configuration.
#####	extra_hosts:
	This is moby network which is getting mapped to 127.0.0.1
#####    volumes:
     	Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

## Docker

	Bring up the docker cluster. The -d option tells us to detach the cluster from the current terminal - essentiall it will run "headless". 
	It is important to run the command from the directory where docker-compose.yml. If we are in a directory without a docker-compose.yml file, docker-compose will throw an error.


```
docker-compose up -d
```
Following output should be on the screen .
Creating network "assignment06bhuvneshsharma_default" with the default driver
Creating assignment06bhuvneshsharma_zookeeper_1
Creating assignment06bhuvneshsharma_mids_1
Creating assignment06bhuvneshsharma_kafka_1

If you want to see the kafka logs live as it comes up use the following command. The -f tells it to keep checking the file for any new additions to the file and print them. To stop this command, use a control-C:


```
docker-compose logs -f kafka

```


```
docker-compose logs kafka | grep -i started

```

        Following output is what we should  see


```
kafka_1      | [2018-06-25 03:57:07,479] INFO [SocketServer brokerId=1] Started 1 acceptor threads (kafka.network.SocketServer)
kafka_1      | [2018-06-25 03:57:07,762] INFO [ReplicaStateMachine controllerId=1] Started replica state machine with initial state -> Map() (kafka.controller.ReplicaStateMachine)
kafka_1      | [2018-06-25 03:57:07,767] INFO [PartitionStateMachine controllerId=1] Started partition state machine with initial state -> Map() (kafka.controller.PartitionStateMachine)
kafka_1      | [2018-06-25 03:57:07,769] INFO [SocketServer brokerId=1] Started processors for 1 acceptors (kafka.network.SocketServer)
kafka_1      | [2018-06-25 03:57:07,773] INFO [KafkaServer id=1] started (kafka.server.KafkaServer)
```


Check and see if our cluster is running. This checks if the docker processes are up and running.

```
docker-compose ps

```

	Following output is what we should  see

```
                 Name                             Command            State                    Ports                  
--------------------------------------------------------------------------------------------------------------------
assignment06bhuvneshsharma_kafka_1       /etc/confluent/docker/run   Up      29092/tcp, 9092/tcp                     
assignment06bhuvneshsharma_mids_1        /bin/bash                   Up      8888/tcp                                
assignment06bhuvneshsharma_zookeeper_1   /etc/confluent/docker/run   Up      2181/tcp, 2888/tcp, 32181/tcp, 3888/tcp 

```

```
docker ps -a

```
You should see the following message to let us know the topic assessment was created correctly:


```

CONTAINER ID        IMAGE                              COMMAND                  CREATED             STATUS              PORTS                                     NAMES
37d1a6592222        confluentinc/cp-kafka:latest       "/etc/confluent/dock…"   6 minutes ago       Up 6 minutes        9092/tcp, 29092/tcp                       assignment06bhuvneshsharma_kafka_1
923e653f59b5        midsw205/base:latest               "/bin/bash"              6 minutes ago       Up 6 minutes        8888/tcp                                  assignment06bhuvneshsharma_mids_1
cf416295a3a5        confluentinc/cp-zookeeper:latest   "/etc/confluent/dock…"   6 minutes ago       Up 6 minutes        2181/tcp, 2888/tcp, 3888/tcp, 32181/tcp   assignment06bhuvneshsharma_zookeeper_1

```


## Create a topic
	Create a topic called assessment in the kafka container using the kafka-topics utility with the following command.

	```
		docker-compose exec kafka \
 			 kafka-topics \
   			 --create \
    			--topic assessment \
    			--partitions 1 \
    			--replication-factor 1 \
    			--if-not-exists \
    			--zookeeper zookeeper:32181
	```

	```
		docker-compose exec kafka kafka-topics --create --topic assessment --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
	```

You should see the following message to let us know the topic assessment was created correctly:

```
Created topic "assessment".
```

Check the topic in the kafka container using the kafka-topics utility:

```
docker-compose exec kafka \
  kafka-topics \
  --describe \
  --topic assessment \
  --zookeeper zookeeper:32181
```

Single line command is as follows

```
docker-compose exec kafka kafka-topics --describe --topic assessment --zookeeper zookeeper:32181

```
You should see the following message

```
	Topic:assessment	PartitionCount:1	ReplicationFactor:1	Configs:
	Topic: assessment	Partition: 0	Leader: 1	Replicas: 1	Isr: 1
```

## Use this docker-compose exec command:

```
docker-compose exec mids bash -c "cat /w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assessment && echo 'Produced 100 messages.'"
```

	This command allows us to login into mids container into a bash shell and then run the command 
	
```
cat /w205/assignment-06-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assessment && echo 'Produced 100 messages.'
```
	Following output should there

	```
	Produced 100 messages.
	```

### kafcat
kafkacat is a command line utility that you can use to test and debug Apache Kafka deployments. You can use kafkacat to produce, consume, and list topic and partition information for Kafka. Described as “netcat for Kafka”, it is a swiss-army knife of tools for inspecting and creating data in Kafka.

kafcat is 


### Subscribe / consume the messages from the kafka topic assessment:

```
docker-compose exec kafka \
  kafka-console-consumer \
    --bootstrap-server localhost:29092 \
    --topic assessment \
    --from-beginning \
    --max-messages 100
```
Command in single line

#### Subscribing for 100 messages from begining

This is using kafka-console-consumer to subscribe on the kafka on port 29092 

```
docker-compose exec kafka kafka-console-consumer --bootstrap-server localhost:29092 --topic assessment --from-beginning --max-messages 100

```
Above command is scanning the messages from beginning and reading the max messages 100 and below message will show up.


```
Processed a total of 100 messages

```

## Tear down the cluster:

```
docker-compose down
```
```
Stopping assignment06bhuvneshsharma_kafka_1 ... done
Stopping assignment06bhuvneshsharma_mids_1 ... done
Stopping assignment06bhuvneshsharma_zookeeper_1 ... done
Removing assignment06bhuvneshsharma_kafka_1 ... done
Removing assignment06bhuvneshsharma_mids_1 ... done
Removing assignment06bhuvneshsharma_zookeeper_1 ... done
Removing network assignment06bhuvneshsharma_default
```

Verify that the cluster is properly down:


```
docker ps -a
```

## Learnings
	Created an Architecture where we can have created set up where we have messaging system. We created docker containers of zookeeper , kafka and mids. We downloaded JSON file [ sample file ] using curl. We learnt how to configure docker-compose yml file to connect zookeeper and kafka and mids.
	We created an multiple containers using the file system which is on the droplet given by berkeley mids program.We also learnt to create a messaging topic on the kafka system. We executed commands to read JSON file , break the records and publish those records to a kafka messaging system. 
	We also created a message subcribtion to read those messages real time. 


## Future
	- Read individual elements of the individual records from Kafka messaging system and use it for analytics
	- Real time enable publishing of records from a web application.
	- Use spark system to run real time analytics on massively parallely system.


