---
title: "Assignment 08 for W205 by Bhuvnesh Sharma"
author: "Bhuvnesh Sharma"

---


#  Assignment 8 from Bhuvnesh Sharma for W205

## Executive Summary

In the age of cloud computing , we are exploring new architectures of managed services architectures. Infrastructure container services like docker have containerized the application architectures. 
We are also exploring different architectures including Lambda architecture , where there is 
- Batch Layer
- Speed layer
- Serving layer 
This data services can we real time data publish subscribe services based on KAFKA. The application gets data from student trying an exam and question attempts. This data can be real time feed into fast , scalable , durable and fault tolerant messaging system. This model can be used to create multiple applications.

With Spark we can make the processing of data frames extremely parallel computation process.

Cloudera HDFS : 
 Hadoop Scalable: HDFS is designed for massive scalability, so you can store unlimited amounts of data in a single platform. As your data needs grow, you can simply add more servers to linearly scale with your business.
 Flexibility: Store data of any type — structured, semi-structured, unstructured — without any upfront modeling. Flexible storage means you always have access to full-fidelity data for a wide range of analytics and use cases.
 Reliability: Automatic, tunable replication means multiple copies of your data are always available for access and protection from data loss. Built-in fault tolerance means servers can fail but your system will remain available for all workloads.


Conceptual Diagram : 
![ALT TEXT](https://databricks.com/wp-content/uploads/2017/04/structured-streaming-kafka-blog-image-1-overview.png)





In this assignment we integrated kafka and spark . We would explore in future assignment integrating the following high level architecture picture. In this assignment we are going to integrate with Cloudera HDFS.

![ALT TEXT](https://www.tutorialspoint.com/apache_kafka/images/integration_spark.jpg)

HDFS is a Java-based file system that provides scalable and reliable data storage, and it was designed to span large clusters of commodity servers. HDFS has demonstrated production scalability of up to 200 PB of storage and a single cluster of 4500 servers, supporting close to a billion files and blocks.

Below is high level architecture of HDFS system.
![ALT TEXT](https://hadoop.apache.org/docs/r1.2.1/images/hdfsarchitecture.gif)

## Approach

We would be following approach

- Login to the droplet using the credentials provided.
- Connect to git and clone the repo assignment-08-bhuvneshsharma.
- cd to the directory  assignment 07.
- Download the json file using curl
- Configure docker-compose yml file
- explain the YML and different pieces of architecture.
	- kafka
	- spark
	- cloudera
	- zookeeper
	- mids 
- Begin docker
- Create kafka topic
- Publish JSON messages.
- Explore PYSPARK to subscribe and read messages
- Import JSON
- Explore python by reading messages and parsing it.
- Use spark to transform the messages.
- Use spark sql to access data from JSON.
- Use spark to transform the messages so that you can land them in hdfs
- Shutdown the docker.

   We are planning to login to the machine where my student droplet has been configured. From that droplet machine we will spin up a cluster with spark,kafka, zookeeper, and the mids container within Docker.
Create a cluster which can map in directory structure virtually and also have the cluster talk to each other.
   Explore the different configurations of the the docker , kafka ,  zookeeper and mids. Then our goal is to stream messages to topics on kafka and then have those message topics be read via spark and pyspark.

### Login to the droplet

Using the account provided by MIDS program login to the droplet

#### Check the directory

```
pwd

cd w205

pwd

```

The result should be as below

```
/home/science/
/home/science/w205
```

### Clone the repository from github

Connect to github using git utility and clone the assignment 08

```
git clone https://github.com/mids-w205-crook/assignment-08-bhuvneshsharma.git

```

####  Move in the directory for the assignment


```
cd /home/science/w205/assignment-08-bhuvneshsharma

```

#### List down all the contents of the directory using following command

```
ls -lrt

```

#### Get the data from the location given the json file using the curl command.

Download the data file from the prescribed location. The json file once downloaded we need to explore the file.

The options -L for curl is to get the file from the location defined by the http location.
-o option downloads the file with file name instead of putting in stdout.


```
curl -L -o assessment-attempts-20180128-121051-nested.json https://goo.gl/f5bRm4
```

#### List down the files in directory again
To confirm that file assessment-attempts-20180128-121051-nested.json has been downloaded from the location https://goo.gl/f5bRm4 run the following command.


```
ls -lrt
```
We see the following output , which confirms that the file is downloaded correctly.

```
-rw-rw-r-- 1 science science 9315053 Jul  1 23:23 assessment-attempts-20180128-121051-nested.json
```

#### Explore the JSON file

We would explore the JSON file to better understand the data file.

```
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
more /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
tail -f /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json
head -10  /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json

```

JSON file appears to be machine readable file and hence it does not have spaces. We would have to use other tools to better explore the file.
We will be using jq command line utility to better understand the JSON.


```
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq .
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq  '.[0]'
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr | head -10

```

jq is command line tool that helps to better understand the json output from machine readable to human readable. Machine readable JSON output is typically created by web applications and hence to save size of packets all spaces are removed.

Output of the one of the command should be similar to the output below

```
        {
          "user_incomplete": false,
          "user_correct": true,
          "options": [
            {
              "checked": true,
              "at": "2017-11-29T06:24:32.426Z",
              "id": "00f18c5b-40f6-483e-b60d-1d1eda18ea13",
              "submitted": 1,
              "correct": true
            },
            {
              "checked": false,
              "id": "a8b278fc-74e2-4d5d-9a50-4158a8b34eff"
            },
```

## create a docker yml file

Move the assignment directory and make the docker-compose.yml file.

```
cd /home/science/w205/assignment-08-bhuvneshsharma

vi docker-compose.yml
```

Insert the following code to the YML file and save it.

```
---
version: '2'
services:
  zookeeper:
    image: confluentinc/cp-zookeeper:latest
    environment:
      ZOOKEEPER_CLIENT_PORT: 32181
      ZOOKEEPER_TICK_TIME: 2000
    expose:
      - "2181"
      - "2888"
      - "32181"
      - "3888"
    extra_hosts:
      - "moby:127.0.0.1"

  kafka:
    image: confluentinc/cp-kafka:latest
    depends_on:
      - zookeeper
    environment:
      KAFKA_BROKER_ID: 1
      KAFKA_ZOOKEEPER_CONNECT: zookeeper:32181
      KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092
      KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1
    volumes:
      - ~/w205:/w205
    expose:
      - "9092"
      - "29092"
    extra_hosts:
      - "moby:127.0.0.1"

  cloudera:
    image: midsw205/cdh-minimal:latest
    expose:
      - "8020" # nn
      - "50070" # nn http
      - "8888" # hue
    #ports:
    #- "8888:8888"
  
  spark:
    image: midsw205/spark-python:0.0.5
    stdin_open: true
    tty: true
    volumes:
      - ~/w205:/w205
    command: bash
    extra_hosts:
      - "moby:127.0.0.1"

  mids:
    image: midsw205/base:latest
    stdin_open: true
    tty: true
    volumes:
      - ~/w205:/w205
    extra_hosts:
      - "moby:127.0.0.1"

```

Alternatively we can copy the docker yml file from course content directory

```
cp ~/w205/course-content/08-Querying-Data/docker-compose.yml .

```


## Understanding docker-compose.yml

The docker-compose.yml is configuring 5 different containers within the cluster. The containers in the cluster are the following
- zookeeper
- kafka
- cloudera
- spark
- mids

###  zookeeper
ZooKeeper is a centralized service for maintaining configuration information, naming, providing distributed synchronization, and providing group services.
Zookeeper is distributed systems configuration management tool. Zookeeper provides multiple features for distributed applications like distributed configuration management, leader election, consensus handling, coordination and locks etc.Zookeeper storing its data on tree like structure. It introduced as Data Tree and nodes introduced as zNodes. Zookeeper follows standard unix notations for file paths.

##### image: confluentinc/cp-zookeeper:latest 
        
This is from where we need to get the configuration of zookeeper. Also the setting is specifing that we need to get the latest configuration.
If configured as following confluentinc/cp-zookeeper:4.0.0 , then it is pointing to use the version 4.0.0

##### ZOOKEEPER_CLIENT_PORT
ZOOKEEPER_CLIENT_PORT: 32181
ZOOKEEPER_TICK_TIME: 2000

ZOOKEEPER_CLIENT_PORT is the port on which we are configuring zookeeper , port configured is 32181. ZooKeeper where to listen for connections by clien          ts such as Kafka

##### expose
 These are the ports which are opened


###  kafka
Kafka is Fast, Scalable, Durable, and Fault-Tolerant publish-subscribe messaging system which can be used to real time data streaming. We can introduce Kafka as Distributed Commit Log which follows publish subscribe architecture. Like many publish-subscribe messaging systems, Kafka maintains feeds of messages in topics. Producers write data to topics and consumers read from topics. Since Kafka is a distributed system, topics are partitioned and replicated across multiple nodes.
Messages in Kafka are simple byte arrays(String , JSON etc). When publishing, message can be attached to a key. Producer distributes all the messages with same key into same partition.

Kafka uses Zookeeper to mange following tasks
- Electing a controller - The controller is one of the brokers and is responsible for maintaining the leader/follower relationship for all the partitions. When a node shuts down, it is the controller that tells other replicas to become partition leaders to replace the partition leaders on the node that is going away. Zookeeper is used to elect a controller, make sure there is only one and elect a new one it if it crashes.
- Cluster membership - Which brokers are alive and part of the cluster? this is also managed through ZooKeeper.
- Topic configuration - Which topics exist, how many partitions each has, where are the replicas, who is the preferred leader, what configuration overrides are set for each topic
- Manage Quotas - How much data is each client allowed to read and write
- Access control - Who is allowed to read and write to which topic (old high level consumer). Which consumer groups exist, who are their members and what is the latest offset each group got from each partition


##### image: confluentinc/cp-kafka:latest
This is from where we need to get the configuration of kafka. Also the setting is specifing that we need to get the latest configuration.If configured as following confluentinc/cp-kafka:4.0.0 , then it is pointing to use the version 4.0.0

##### depends_on
This configuration requests points to that the fact that this container of kafka depends on zookeeper container.

##### KAFKA_ZOOKEEPER_CONNECT
Connects to zookeeper container at port 32181
##### KAFKA_ADVERTISED_LISTENERS 
Advertised listeners is required for starting up the Docker image because it is important to think through how other clients are going to connect to kafka. In a Docker environment, you will need to make sure that your clients can connect to Kafka and other services. Advertised listeners is how it gives out a host name that can be reached by the client.
KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://kafka:29092

##### KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR
 This is needed when you are running with a single-node cluster. If you have three or more nodes, you do not need to change this from the default. Current setting is 1.

#####    volumes:
Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

#####    expose:
These are the ports which are exposed.
         - "9092"
         - "29092"
#####   extra_hosts:
        This is moby network which is getting mapped to 127.0.0.1
        - "moby:127.0.0.1"

### 3) cloudera
Cloudera is the Hadoop set up

####     image: midsw205/cdh-minimal:latest
 This is from where we need to get the configuration of cloudera. Also the setting is specifing that we need to get the midsw205/cdh-minimal:latest  configuration.

####  expose
These are the ports which are exposed.
      - "8020" # nn
      - "50070" # nn http
      - "8888" # hue

### 4) spark

Spark is a fast and general cluster computing system for Big Data. It provides high-level APIs in Scala, Java, Python, and R, and an optimized engine that supports general computation graphs for data analysis. It also supports a rich set of higher-level tools including Spark SQL for SQL and DataFrames, MLlib for machine learning, GraphX for graph processing, and Spark Streaming for stream processing.

Spark Streaming API enables scalable, high-throughput, fault-tolerant stream processing of live data streams. Data can be ingested from many sources like Kafka, Flume, Twitter, etc., and can be processed using complex algorithms such as high-level functions like map, reduce, join and window. Finally, processed data can be pushed out to filesystems, databases, and live dash-boards. Resilient Distributed Datasets (RDD) is a fundamental data structure of Spark. It is an immutable distributed collection of objects. Each dataset in RDD is divided into logical partitions, which may be computed on different nodes of the cluster.


#####     image: midsw205/spark-python:0.0.5
 This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the spark-python:0.0.5 configuration.
#####    volumes:
Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.
#####    command
The default Shell that needs to be open as first command
#####   extra_hosts:
 This is moby network which is getting mapped to 127.0.0.1
 - "moby:127.0.0.1"
#####    stdin_open
#####    tty
A tty is essentially a text input output environment aka shell.

### 5) mids

#####     image: midsw205/base:latest
This is from where we need to get the configuration of mids. Also the setting is specifing that we need to get the latest configuration.
#####   extra_hosts:
This is moby network which is getting mapped to 127.0.0.1
#####    volumes:
        Maps /home/science/w205 from the droplet to /w205 on the docker container. This allows docker to share the file system.

## Docker

Bring up the docker cluster. The -d option tells us to detach the cluster from the current terminal - essentiall it will run "headless".
It is important to run the command from the directory where docker-compose.yml. If we are in a directory without a docker-compose.yml file, docker-compose will throw an error.

```
docker-compose up -d
```

Following output should be on the screen .

```
Creating network "assignment08bhuvneshsharma_default" with the default driver
Creating assignment08bhuvneshsharma_mids_1
Creating assignment08bhuvneshsharma_cloudera_1
Creating assignment08bhuvneshsharma_spark_1
Creating assignment08bhuvneshsharma_zookeeper_1
Creating assignment08bhuvneshsharma_kafka_1

```


If you want to see the kafka logs live as it comes up use the following command. The -f tells it to keep checking the file for any new additions to the file and print them. To stop this command, use a control-C:

```
docker-compose logs -f kafka
```

Following output is what we should  see

```
kafka_1      | [2018-07-01 23:46:19,211] INFO [SocketServer brokerId=1] Started 1 acceptor threads (kafka.network.SocketServer)
kafka_1      | [2018-07-01 23:46:19,448] INFO [ReplicaStateMachine controllerId=1] Started replica state machine with initial state -> Map() (kafka.controller.ReplicaStateMachine)
kafka_1      | [2018-07-01 23:46:19,457] INFO [PartitionStateMachine controllerId=1] Started partition state machine with initial state -> Map() (kafka.controller.PartitionStateMachine)
kafka_1      | [2018-07-01 23:46:19,506] INFO [SocketServer brokerId=1] Started processors for 1 acceptors (kafka.network.SocketServer)
kafka_1      | [2018-07-01 23:46:19,510] INFO [KafkaServer id=1] started (kafka.server.KafkaServer)
```

Check and see if our cluster is running. This checks if the docker processes are up and running.

```
docker-compose ps
```

Following output is what we should  see

```
                 Name                             Command            State                                         Ports                                        
---------------------------------------------------------------------------------------------------------------------------------------------------------------
assignment08bhuvneshsharma_cloudera_1    cdh_startup_script.sh       Up      11000/tcp, 11443/tcp, 19888/tcp, 50070/tcp, 8020/tcp, 8088/tcp, 8888/tcp, 9090/tcp 
assignment08bhuvneshsharma_kafka_1       /etc/confluent/docker/run   Up      29092/tcp, 9092/tcp                                                                
assignment08bhuvneshsharma_mids_1        /bin/bash                   Up      8888/tcp                                                                           
assignment08bhuvneshsharma_spark_1       docker-entrypoint.sh bash   Up                                                                                         
assignment08bhuvneshsharma_zookeeper_1   /etc/confluent/docker/run   Up      2181/tcp, 2888/tcp, 32181/tcp, 3888/tcp                                            

```

```
docker ps -a

```
You should see the following message to let us know the topic assessment was created correctly:

```
CONTAINER ID        IMAGE                              COMMAND                  CREATED             STATUS                        PORTS                                                                                NAMES
19323e2f92be        confluentinc/cp-kafka:latest       "/etc/confluent/dock…"   4 minutes ago       Up 4 minutes                  9092/tcp, 29092/tcp                                                                  assignment08bhuvneshsharma_kafka_1
2c4a8129d684        midsw205/spark-python:0.0.5        "docker-entrypoint.s…"   4 minutes ago       Up 4 minutes                                                                                                       assignment08bhuvneshsharma_spark_1
6959e1064f7c        confluentinc/cp-zookeeper:latest   "/etc/confluent/dock…"   4 minutes ago       Up 4 minutes                  2181/tcp, 2888/tcp, 3888/tcp, 32181/tcp                                              assignment08bhuvneshsharma_zookeeper_1
45a9b12be9e6        midsw205/cdh-minimal:latest        "cdh_startup_script.…"   4 minutes ago       Up 4 minutes                  8020/tcp, 8088/tcp, 8888/tcp, 9090/tcp, 11000/tcp, 11443/tcp, 19888/tcp, 50070/tcp   assignment08bhuvneshsharma_cloudera_1
32f7b5abce14        midsw205/base:latest               "/bin/bash"              4 minutes ago       Up 4 minutes                  8888/tcp                                                                             assignment08bhuvneshsharma_mids_1


```
## Check HDFS File system

Check HDFS file system using following command. 

```
docker-compose exec cloudera hadoop fs -ls /tmp/

```
With the above command we are logging in the container cloudera and then running hadoop fs command which is basically listing down all the files / directories in /tmp.

The hadoop hdfs is a separate file system from our local linux file system. 
The directories are different and have different paths. You will need to use the following command to view a directory listing of the hdfs directory /tmp. If the cluster is first coming up, or if you have recently added a directory or file, it may take time to show up. Remember that big data architectures are eventually consistent and not immediately consistent.

```
Found 2 items
drwxrwxrwt   - mapred mapred              0 2018-02-06 18:27 /tmp/hadoop-yarn
drwx-wx-wx   - root   supergroup          0 2018-07-08 11:29 /tmp/hive

```

## Create a topic
Create a topic called assessment in the kafka container using the kafka-topics utility with the following command.

```
                docker-compose exec kafka \
                         kafka-topics \
                         --create \
                        --topic assessment \
                        --partitions 1 \
                        --replication-factor 1 \
                        --if-not-exists \
                        --zookeeper zookeeper:32181
```
	
Same command in 1 line which creates "assessment" topic

```
docker-compose exec kafka kafka-topics --create --topic assessment --partitions 1 --replication-factor 1 --if-not-exists --zookeeper zookeeper:32181
```

You should see the following message to let us know the topic assessment was created correctly:

```
Created topic "assessment".
```

Check the topic in the kafka container using the kafka-topics utility:

```
		docker-compose exec kafka \
			  kafka-topics \
			  --describe \
			  --topic assessment \
			  --zookeeper zookeeper:32181
```

Single line command is as follows

```
docker-compose exec kafka kafka-topics --describe --topic assessment --zookeeper zookeeper:32181
```

You should see the following message

```
Topic:assessment	PartitionCount:1	ReplicationFactor:1	Configs:
Topic: assessment	Partition: 0	Leader: 1	Replicas: 1	Isr: 1
```

## Use this docker-compose exec command:

This is a microservice which is using kafcat utility to read the json file , Next we are going to use jq utility as well. We are using jq utility to parse the JSON file and send messages to the "assessment" topic.
```
docker-compose exec mids bash -c "cat /w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json"
docker-compose exec mids bash -c "cat /w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.'"
docker-compose exec mids bash -c "cat /w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort"
docker-compose exec mids bash -c "cat /w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr"
docker-compose exec mids bash -c "cat /w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[][]' -r | sort | uniq -c | sort -gr | head -10"

docker-compose exec mids bash -c "cat /w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assessment && echo 'Produced  messages.'"
```

These commands allows us to login into mids container into a bash shell and then run the commands. Last command parsed the json file with kafkacat utility within the mids container and posted the messages to kafka queue. Same can be done from the droplet also via following command.

```
cat /home/science/w205/assignment-08-bhuvneshsharma/assessment-attempts-20180128-121051-nested.json | jq '.[]' -c | kafkacat -P -b kafka:29092 -t assessment && echo 'Produced messages.'
```


Following output should there
```
Produced  messages.
```

### kafcat
kafkacat is a command line utility that you can use to test and debug Apache Kafka deployments. You can use kafkacat to produce, consume, and list topic and partition information for Kafka. Described as “netcat for Kafka”, it is a swiss-army knife of tools for inspecting and creating data in Kafka.

### PYSPARK

In the spark container, run the python spark command line utility called pyspark.The Spark Python API (PySpark) exposes the Spark programming model to Python.

```
docker-compose exec spark pyspark
```


You should see the following output , Pyspark is the which we are going to use to subscribe to the messages topic which has been shared in the kafka queues

```
Type "help", "copyright", "credits" or "license" for more information.
Using Spark's default log4j profile: org/apache/spark/log4j-defaults.properties
Setting default log level to "WARN".
To adjust logging level use sc.setLogLevel(newLevel). For SparkR, use setLogLevel(newLevel).
18/07/02 02:56:42 WARN NativeCodeLoader: Unable to load native-hadoop library for your platform... using builtin-java classes where applicable
18/07/02 02:56:49 WARN ObjectStore: Version information not found in metastore. hive.metastore.schema.verification is not enabled so recording the schema version 1.2.0
18/07/02 02:56:49 WARN ObjectStore: Failed to get database default, returning NoSuchObjectException
18/07/02 02:56:50 WARN ObjectStore: Failed to get database global_temp, returning NoSuchObjectException
Welcome to
      ____              __
     / __/__  ___ _____/ /__
    _\ \/ _ \/ _ `/ __/  '_/
   /__ / .__/\_,_/_/ /_/\_\   version 2.2.0
      /_/

Using Python version 3.6.1 (default, May 11 2017 13:09:58)
SparkSession available as 'spark'.
>>> 
```

assessment_details is thespark data frame which is built on top of a spark RDD, using python code we are going read the topic assessment from the kafka queue @ port 29092. Current configuration is reading the messages from the start and ending at the latest messages.

```
		assessment_details = spark \
			.read \
  			.format("kafka") \
 			.option("kafka.bootstrap.servers", "kafka:29092") \
  			.option("subscribe","assessment") \
  			.option("startingOffsets", "earliest") \
  			.option("endingOffsets", "latest") \
  			.load() 
```

The same command in 1 single line , we are reading the message topic from the kafka queue. The output of this from would be a data frame and we would parse the data frame to analyze the results.
```
assessment_details = spark.read.format("kafka").option("kafka.bootstrap.servers", "kafka:29092").option("subscribe","assessment").option("startingOffsets", "earliest").option("endingOffsets", "latest").load() 
```

Let us try to Persists the DataFrame with the default storage level using the following command. 
Without it every time something isn't in memory it will generate a warning message.This is due to spark's use of "lazy evaluation" which is a hallmark of big data architecture. Add that to our big data architecture we have seen so far: immutable, eventually consistent, lazy evaluation.

```
assessment_details.cache()
```

Now lets print the schema for the data frame assessment_details
Print the schema for the data frame. Note that the values are shown in binary, which we cant read.

```
assessment_details.printSchema()
```

Following output @ pyspark

```
>>> assessment_details.printSchema()
root
 |-- key: binary (nullable = true)
 |-- value: binary (nullable = true)
 |-- topic: string (nullable = true)
 |-- partition: integer (nullable = true)
 |-- offset: long (nullable = true)
 |-- timestamp: timestamp (nullable = true)
 |-- timestampType: integer (nullable = true)

```
 This is RDD data frame . Resilient Distributed Datasets (RDD) is a fundamental data structure of Spark. It is an immutable distributed collection of objects. Each dataset in RDD is divided into logical partitions, which may be computed on different nodes of the cluster. RDDs can contain any type of Python, Java, or Scala objects, including user-defined classes.

Since we have a hard time reading binary for the value, let's translate the key and value into strings so we can read them. Create a new data frame which stores the numbers as strings. Since data frames are immutable, so we cannot change them in place, we have to make a copy:



```
assessment_details_string = assessment_details.select(assessment_details.value.cast('string'))

```

Display the entire data frame. Note that now we can read the key and value:

```
assessment_details_string.show()
```

Show function will have following output


```
+--------------------+
|               value|
+--------------------+
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
|{"keen_timestamp"...|
+--------------------+
only showing top 20 rows

```

 We may see some unicode characters. Most western alphabets need only 7 bits to store all characters, so we can store it in 1 byte (8 bits).
 However, other languages of the world have their own alphabets and need 2 bytes to store a single character. Unicode is the standard for this, but unicode has the disadvantage of storing 2 bytes for every character whether it needs it or not. As a compromise, utf-8 format was invented. This format will use only 1 byte if the character needs only 1 byte, and 2 bytes if the character needs 2 bytes. It can do this by using the extra bit as a signal.

The following code will set standard output to write data using utf-8 instead of unicode. In the modern era, it's almost always a good idea to always use utf-8:

```
import sys
sys.stdout = open(sys.stdout.fileno(), mode='w', encoding='utf8', buffering=1)
```


```
import json
assessment_details_string.rdd.map(lambda x: json.loads(x.value)).toDF().show()
```

Following output should be observed 
```
>>> assessment_details_string.rdd.map(lambda x: json.loads(x.value)).toDF().show()
/spark-2.2.0-bin-hadoop2.6/python/pyspark/sql/session.py:351: UserWarning: Using RDD of dict to inferSchema is deprecated. Use pyspark.sql.Row instead
  warnings.warn("Using RDD of dict to inferSchema is deprecated. "
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
|        base_exam_id|certification|           exam_name|   keen_created_at|             keen_id|    keen_timestamp|max_attempts|           sequences|          started_at|        user_exam_id|
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
|37f0a30a-7464-11e...|        false|Normal Forms and ...| 1516717442.735266|5a6745820eb8ab000...| 1516717442.735266|         1.0|Map(questions -> ...|2018-01-23T14:23:...|6d4089e4-bde5-4a2...|
|37f0a30a-7464-11e...|        false|Normal Forms and ...| 1516717377.639827|5a674541ab6b0a000...| 1516717377.639827|         1.0|Map(questions -> ...|2018-01-23T14:21:...|2fec1534-b41f-441...|
|4beeac16-bb83-4d5...|        false|The Principles of...| 1516738973.653394|5a67999d3ed3e3000...| 1516738973.653394|         1.0|Map(questions -> ...|2018-01-23T20:22:...|8edbc8a8-4d26-429...|
|4beeac16-bb83-4d5...|        false|The Principles of...|1516738921.1137421|5a6799694fc7c7000...|1516738921.1137421|         1.0|Map(questions -> ...|2018-01-23T20:21:...|c0ee680e-8892-4e6...|
|6442707e-7488-11e...|        false|Introduction to B...| 1516737000.212122|5a6791e824fccd000...| 1516737000.212122|         1.0|Map(questions -> ...|2018-01-23T19:48:...|e4525b79-7904-405...|
|8b4488de-43a5-4ff...|        false|        Learning Git| 1516740790.309757|5a67a0b6852c2a000...| 1516740790.309757|         1.0|Map(questions -> ...|2018-01-23T20:51:...|3186dafa-7acf-47e...|
|e1f07fac-5566-4fd...|        false|Git Fundamentals ...|1516746279.3801291|5a67b627cc80e6000...|1516746279.3801291|         1.0|Map(questions -> ...|2018-01-23T22:24:...|48d88326-36a3-4cb...|
|7e2e0b53-a7ba-458...|        false|Introduction to P...| 1516743820.305464|5a67ac8cb0a5f4000...| 1516743820.305464|         1.0|Map(questions -> ...|2018-01-23T21:43:...|bb152d6b-cada-41e...|
|1a233da8-e6e5-48a...|        false|Intermediate Pyth...|  1516743098.56811|5a67a9ba060087000...|  1516743098.56811|         1.0|Map(questions -> ...|2018-01-23T21:31:...|70073d6f-ced5-4d0...|
|7e2e0b53-a7ba-458...|        false|Introduction to P...| 1516743764.813107|5a67ac54411aed000...| 1516743764.813107|         1.0|Map(questions -> ...|2018-01-23T21:42:...|9eb6d4d6-fd1f-4f3...|
|4cdf9b5f-fdb7-4a4...|        false|A Practical Intro...|1516744091.3127241|5a67ad9b2ff312000...|1516744091.3127241|         1.0|Map(questions -> ...|2018-01-23T21:45:...|093f1337-7090-457...|
|e1f07fac-5566-4fd...|        false|Git Fundamentals ...|1516746256.5878439|5a67b610baff90000...|1516746256.5878439|         1.0|Map(questions -> ...|2018-01-23T22:24:...|0f576abb-958a-4c0...|
|87b4b3f9-3a86-435...|        false|Introduction to M...|  1516743832.99235|5a67ac9837b82b000...|  1516743832.99235|         1.0|Map(questions -> ...|2018-01-23T21:40:...|0c18f48c-0018-450...|
|a7a65ec6-77dc-480...|        false|   Python Epiphanies|1516743332.7596769|5a67aaa4f21cc2000...|1516743332.7596769|         1.0|Map(questions -> ...|2018-01-23T21:34:...|b38ac9d8-eef9-495...|
|7e2e0b53-a7ba-458...|        false|Introduction to P...| 1516743750.097306|5a67ac46f7bce8000...| 1516743750.097306|         1.0|Map(questions -> ...|2018-01-23T21:41:...|bbc9865f-88ef-42e...|
|e5602ceb-6f0d-11e...|        false|Python Data Struc...|1516744410.4791961|5a67aedaf34e85000...|1516744410.4791961|         1.0|Map(questions -> ...|2018-01-23T21:51:...|8a0266df-02d7-44e...|
|e5602ceb-6f0d-11e...|        false|Python Data Struc...|1516744446.3999851|5a67aefef5e149000...|1516744446.3999851|         1.0|Map(questions -> ...|2018-01-23T21:53:...|95d4edb1-533f-445...|
|f432e2e3-7e3a-4a7...|        false|Working with Algo...| 1516744255.840405|5a67ae3f0c5f48000...| 1516744255.840405|         1.0|Map(questions -> ...|2018-01-23T21:50:...|f9bc1eff-7e54-42a...|
|76a682de-6f0c-11e...|        false|Learning iPython ...| 1516744023.652257|5a67ad579d5057000...| 1516744023.652257|         1.0|Map(questions -> ...|2018-01-23T21:46:...|dc4b35a7-399a-4bd...|
|a7a65ec6-77dc-480...|        false|   Python Epiphanies|1516743398.6451161|5a67aae6753fd6000...|1516743398.6451161|         1.0|Map(questions -> ...|2018-01-23T21:35:...|d0f8249a-597e-4e1...|
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
only showing top 20 rows

```


Write the assessment  data frame to a parquet file in hadoop hdfs. Note that this is writing to hadoop hdfs and not to the local linux / unix  file system. 
HDFS is intended to have a virtual presence on all nodes in the hadoop cluster.
Apache Parquet is a columnar storage format available to any project in the Hadoop ecosystem, regardless of the choice of data processing framework, data model or programming language. 
Parquet format is a binary format for storing data in binary format in a file in columnar format. Parquet files are immutable. Immutable files are a critical piece of big data architecture. It allows them to be pushed out in a hadoop cluster, stored in object store (which we could use an elastic query resource against), delivered in content delivery networks, etc.


```
assessment_details_string.write.parquet("/tmp/commits")
```


Login the cloudera container and check the files on the file system.
```
docker-compose exec cloudera hadoop fs -ls /tmp/
docker-compose exec cloudera hadoop fs -ls /tmp/commits
```



Create a new data frame extracted_assessment_details_string to hold data in JSON format.

```
extracted_assessment_details_string = assessment_details_string.rdd.map(lambda x: json.loads(x.value)).toDF()

```

```
assessment_extracted_commits = assessment_details_string.rdd.map(lambda x: json.loads(x.value)).toDF()
assessment_extracted_commits.show()
assessment_extracted_commits.printSchema()
```

```
>>> assessment_extracted_commits.printSchema()
root
 |-- base_exam_id: string (nullable = true)
 |-- certification: string (nullable = true)
 |-- exam_name: string (nullable = true)
 |-- keen_created_at: string (nullable = true)
 |-- keen_id: string (nullable = true)
 |-- keen_timestamp: string (nullable = true)
 |-- max_attempts: string (nullable = true)
 |-- sequences: map (nullable = true)
 |    |-- key: string
 |    |-- value: array (valueContainsNull = true)
 |    |    |-- element: map (containsNull = true)
 |    |    |    |-- key: string
 |    |    |    |-- value: boolean (valueContainsNull = true)
 |-- started_at: string (nullable = true)
 |-- user_exam_id: string (nullable = true)


```

Create a temporary table assessments using the output of data frame assessment_extracted_commits


```
assessment_extracted_commits.registerTempTable('assessments') 
```

Query the temp table assessments for everything in the table for the first 10 records. The output of the query is presented below

```

spark.sql("select * from assessments limit 10").show()

```

Following output should be observed.

```

+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
|        base_exam_id|certification|           exam_name|   keen_created_at|             keen_id|    keen_timestamp|max_attempts|           sequences|          started_at|        user_exam_id|
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
|37f0a30a-7464-11e...|        false|Normal Forms and ...| 1516717442.735266|5a6745820eb8ab000...| 1516717442.735266|         1.0|Map(questions -> ...|2018-01-23T14:23:...|6d4089e4-bde5-4a2...|
|37f0a30a-7464-11e...|        false|Normal Forms and ...| 1516717377.639827|5a674541ab6b0a000...| 1516717377.639827|         1.0|Map(questions -> ...|2018-01-23T14:21:...|2fec1534-b41f-441...|
|4beeac16-bb83-4d5...|        false|The Principles of...| 1516738973.653394|5a67999d3ed3e3000...| 1516738973.653394|         1.0|Map(questions -> ...|2018-01-23T20:22:...|8edbc8a8-4d26-429...|
|4beeac16-bb83-4d5...|        false|The Principles of...|1516738921.1137421|5a6799694fc7c7000...|1516738921.1137421|         1.0|Map(questions -> ...|2018-01-23T20:21:...|c0ee680e-8892-4e6...|
|6442707e-7488-11e...|        false|Introduction to B...| 1516737000.212122|5a6791e824fccd000...| 1516737000.212122|         1.0|Map(questions -> ...|2018-01-23T19:48:...|e4525b79-7904-405...|
|8b4488de-43a5-4ff...|        false|        Learning Git| 1516740790.309757|5a67a0b6852c2a000...| 1516740790.309757|         1.0|Map(questions -> ...|2018-01-23T20:51:...|3186dafa-7acf-47e...|
|e1f07fac-5566-4fd...|        false|Git Fundamentals ...|1516746279.3801291|5a67b627cc80e6000...|1516746279.3801291|         1.0|Map(questions -> ...|2018-01-23T22:24:...|48d88326-36a3-4cb...|
|7e2e0b53-a7ba-458...|        false|Introduction to P...| 1516743820.305464|5a67ac8cb0a5f4000...| 1516743820.305464|         1.0|Map(questions -> ...|2018-01-23T21:43:...|bb152d6b-cada-41e...|
|1a233da8-e6e5-48a...|        false|Intermediate Pyth...|  1516743098.56811|5a67a9ba060087000...|  1516743098.56811|         1.0|Map(questions -> ...|2018-01-23T21:31:...|70073d6f-ced5-4d0...|
|7e2e0b53-a7ba-458...|        false|Introduction to P...| 1516743764.813107|5a67ac54411aed000...| 1516743764.813107|         1.0|Map(questions -> ...|2018-01-23T21:42:...|9eb6d4d6-fd1f-4f3...|
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+


```


Select a particular column within the assessments table and limt the output 10.

```
spark.sql("select exam_name from assessments limit 10").show()

```

Following output is observed

```
+--------------------+
|           exam_name|
+--------------------+
|Normal Forms and ...|
|Normal Forms and ...|
|The Principles of...|
|The Principles of...|
|Introduction to B...|
|        Learning Git|
|Git Fundamentals ...|
|Introduction to P...|
|Intermediate Pyth...|
|Introduction to P...|
+--------------------+
```


Perform where clause on the query. Select all records which have exam_name='Learning Git'

```
>>> spark.sql("select exam_name , started_at from assessments where exam_name='Learning Git' limit 10").show()

```
Following output is recieved.

```
+------------+--------------------+
|   exam_name|          started_at|
+------------+--------------------+
|Learning Git|2018-01-23T20:51:...|
|Learning Git|2018-01-23T05:05:...|
|Learning Git|2018-01-23T11:13:...|
|Learning Git|2017-12-08T07:38:...|
|Learning Git|2017-12-03T06:20:...|
|Learning Git|2017-12-23T07:28:...|
|Learning Git|2018-01-23T12:53:...|
|Learning Git|2018-01-23T14:02:...|
|Learning Git|2018-01-23T14:05:...|
|Learning Git|2018-01-08T22:01:...|
+------------+--------------------+

```

Query the commit table for where clause 

```
>>> spark.sql("select * from assessments where exam_name='Learning Git' limit 10").show()
+--------------------+-------------+------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
|        base_exam_id|certification|   exam_name|   keen_created_at|             keen_id|    keen_timestamp|max_attempts|           sequences|          started_at|        user_exam_id|
+--------------------+-------------+------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
|8b4488de-43a5-4ff...|        false|Learning Git| 1516740790.309757|5a67a0b6852c2a000...| 1516740790.309757|         1.0|Map(questions -> ...|2018-01-23T20:51:...|3186dafa-7acf-47e...|
|8b4488de-43a5-4ff...|        false|Learning Git|1516683985.8066449|5a66c2d1561862000...|1516683985.8066449|         1.0|Map(questions -> ...|2018-01-23T05:05:...|9e382121-e5cb-4fd...|
|8b4488de-43a5-4ff...|        false|Learning Git| 1516706081.236501|5a671921a8d4e5000...| 1516706081.236501|         1.0|Map(questions -> ...|2018-01-23T11:13:...|f51f9597-2996-4b8...|
|8b4488de-43a5-4ff...|        false|Learning Git|1512718784.7242069|5a2a41c07c9197000...|1512718784.7242069|         1.0|Map(questions -> ...|2017-12-08T07:38:...|70e88815-cccb-4c4...|
|8b4488de-43a5-4ff...|        false|Learning Git|1512282088.0000949|5a2397e8af7e56000...|1512282088.0000949|         1.0|Map(questions -> ...|2017-12-03T06:20:...|c1f0a899-6b91-4ee...|
|8b4488de-43a5-4ff...|        false|Learning Git|1514014227.4384561|5a3e06138966e4000...|1514014227.4384561|         1.0|Map(questions -> ...|2017-12-23T07:28:...|9d3d647f-f55f-4ca...|
|8b4488de-43a5-4ff...|        false|Learning Git|1516712236.7059181|5a67312cb9dd43000...|1516712236.7059181|         1.0|Map(questions -> ...|2018-01-23T12:53:...|bb180146-4963-40e...|
|8b4488de-43a5-4ff...|        false|Learning Git| 1516716189.847533|5a67409df0f4b4000...| 1516716189.847533|         1.0|Map(questions -> ...|2018-01-23T14:02:...|76742c72-5f95-43b...|
|8b4488de-43a5-4ff...|        false|Learning Git| 1516716429.622679|5a67418dc698a1000...| 1516716429.622679|         1.0|Map(questions -> ...|2018-01-23T14:05:...|e24604bc-f079-4d7...|
|8b4488de-43a5-4ff...|        false|Learning Git|1515449071.0685251|5a53eaef51ea49000...|1515449071.0685251|         1.0|Map(questions -> ...|2018-01-08T22:01:...|df577817-96a2-434...|
+--------------------+-------------+------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+
```


Query the assessments table for all records and group by their counts.

```
spark.sql("select count(base_exam_id),exam_name from assessments group by exam_name").show()
```

Following output is recieved.
```
+-------------------+--------------------+                                      
|count(base_exam_id)|           exam_name|
+-------------------+--------------------+
|                  9|Learning Data Mod...|
|                 15|Networking for Pe...|
|                158|Introduction to J...|
|                 16|Learning Apache H...|
|                  2|Learning Spring P...|
|                 17|Learning iPython ...|
|                162|Introduction to P...|
|                 35|Learning C# Best ...|
|                 14|Introduction to A...|
|                  9|A Practical Intro...|
|                 15|I'm a Software Ar...|
|                 75|Introduction to B...|
|                  4|       View Updating|
|                 25|Mastering Python ...|
|                 43|Intermediate C# P...|
|                  5|Starting a Grails...|
|                  9|Introduction to A...|
|                 21|JavaScript Templa...|
|                 10|Being a Better In...|
|                 34|Mastering Advance...|
+-------------------+--------------------+
only showing top 20 rows

```

What is the most popular courses which have been registered can be queried by the following query.

```
>>> spark.sql("select count(base_exam_id) COUNT ,exam_name from assessments group by exam_name order by COUNT desc").show()

```
Following output is recieved 

```

+-----+--------------------+
|COUNT|           exam_name|
+-----+--------------------+
|  394|        Learning Git|
|  162|Introduction to P...|
|  158|Introduction to J...|
|  158|Intermediate Pyth...|
|  128|Learning to Progr...|
|  119|Introduction to M...|
|  109|Software Architec...|
|   95|Beginning C# Prog...|
|   85|    Learning Eclipse|
|   80|Learning Apache M...|
|   79|Beginning Program...|
|   77|       Mastering Git|
|   75|Introduction to B...|
|   67|Advanced Machine ...|
|   59|Learning Linux Sy...|
|   58|JavaScript: The G...|
|   57|        Learning SQL|
|   53|Practical Java Pr...|
|   52|    HTML5 The Basics|
|   51|   Python Epiphanies|
+-----+--------------------+
only showing top 20 rows

```

Select keen_id from temp table assessments limited to 10 records

```
>>> spark.sql("select keen_id from assessments limit 10").show()
+--------------------+
|             keen_id|
+--------------------+
|5a6745820eb8ab000...|
|5a674541ab6b0a000...|
|5a67999d3ed3e3000...|
|5a6799694fc7c7000...|
|5a6791e824fccd000...|
|5a67a0b6852c2a000...|
|5a67b627cc80e6000...|
|5a67ac8cb0a5f4000...|
|5a67a9ba060087000...|
|5a67ac54411aed000...|
+--------------------+

```

Check for the time stamp and question 1 and whether user completed it or not limit the query for 10 records.

```
>>> spark.sql("select keen_timestamp, sequences.questions[0].user_incomplete from assessments limit 10").show()
+------------------+-------------------------------------------------------+
|    keen_timestamp|sequences[questions] AS `questions`[0][user_incomplete]|
+------------------+-------------------------------------------------------+
| 1516717442.735266|                                                   true|
| 1516717377.639827|                                                  false|
| 1516738973.653394|                                                  false|
|1516738921.1137421|                                                  false|
| 1516737000.212122|                                                  false|
| 1516740790.309757|                                                  false|
|1516746279.3801291|                                                  false|
| 1516743820.305464|                                                  false|
|  1516743098.56811|                                                  false|
| 1516743764.813107|                                                  false|
+------------------+-------------------------------------------------------+

```

Repeated the process for questions 1 and questions 2

```
>>> spark.sql("select keen_timestamp, sequences.questions[1].user_incomplete from assessments limit 10").show()
+------------------+-------------------------------------------------------+
|    keen_timestamp|sequences[questions] AS `questions`[1][user_incomplete]|
+------------------+-------------------------------------------------------+
| 1516717442.735266|                                                  false|
| 1516717377.639827|                                                   true|
| 1516738973.653394|                                                  false|
|1516738921.1137421|                                                   true|
| 1516737000.212122|                                                  false|
| 1516740790.309757|                                                  false|
|1516746279.3801291|                                                   null|
| 1516743820.305464|                                                  false|
|  1516743098.56811|                                                  false|
| 1516743764.813107|                                                   true|
+------------------+-------------------------------------------------------+

>>> spark.sql("select keen_timestamp, sequences.questions[2].user_incomplete from assessments limit 10").show()
+------------------+-------------------------------------------------------+
|    keen_timestamp|sequences[questions] AS `questions`[2][user_incomplete]|
+------------------+-------------------------------------------------------+
| 1516717442.735266|                                                  false|
| 1516717377.639827|                                                  false|
| 1516738973.653394|                                                  false|
|1516738921.1137421|                                                  false|
| 1516737000.212122|                                                  false|
| 1516740790.309757|                                                  false|
|1516746279.3801291|                                                   null|
| 1516743820.305464|                                                  false|
|  1516743098.56811|                                                  false|
| 1516743764.813107|                                                  false|
+------------------+-------------------------------------------------------+

```

Select a table column which does not exist in the data set .... output is expected to be null.

```
>>> spark.sql("select sequences.abc123 from assessments limit 10").show()
+------+
|abc123|
+------+
|  null|
|  null|
|  null|
|  null|
|  null|
|  null|
|  null|
|  null|
|  null|
|  null|
+------+
```


Create a function which reads the JSON firle and returns a data frame which has keen_id , sequence_id

```
def my_lambda_sequences_id(x):
    raw_dict = json.loads(x.value)
    my_dict = {"keen_id" : raw_dict["keen_id"], "sequences_id" : raw_dict["sequences"]["id"]}
    return my_dict
```



Create a new data frame my_sequences and then create a temp table sequences.


```
my_sequences = assessment_details_string.rdd.map(my_lambda_sequences_id).toDF()

my_sequences.registerTempTable('sequences')

```

```
>>> spark.sql("select sequences_id from sequences limit 10").show()
+--------------------+
|        sequences_id|
+--------------------+
|5b28a462-7a3b-42e...|
|5b28a462-7a3b-42e...|
|b370a3aa-bf9e-4c1...|
|b370a3aa-bf9e-4c1...|
|04a192c1-4f5c-4ac...|
|e7110aed-0d08-4cb...|
|5251db24-2a6e-424...|
|066b5326-e547-4da...|
|8ac691f8-8c1a-403...|
|066b5326-e547-4da...|
+--------------------+
```

Join the data from temp table sequences and assessments based on keen_id

```
>>> spark.sql("select a.keen_id, a.keen_timestamp, s.sequences_id from assessments a join sequences s on a.keen_id = s.keen_id limit 10").show()
+--------------------+------------------+--------------------+
|             keen_id|    keen_timestamp|        sequences_id|
+--------------------+------------------+--------------------+
|5a17a67efa1257000...|1511499390.3836269|8ac691f8-8c1a-403...|
|5a26ee9cbf5ce1000...|1512500892.4166169|9bd87823-4508-4e0...|
|5a29dcac74b662000...|1512692908.8423469|e7110aed-0d08-4cb...|
|5a2fdab0eabeda000...|1513085616.2275269|cd800e92-afc3-447...|
|5a30105020e9d4000...|1513099344.8624721|8ac691f8-8c1a-403...|
|5a3a6fc3f0a100000...| 1513779139.354213|e7110aed-0d08-4cb...|
|5a4e17fe08a892000...|1515067390.1336551|9abd5b51-6bd8-11e...|
|5a4f3c69cc6444000...| 1515142249.858722|083844c5-772f-48d...|
|5a51b21bd0480b000...| 1515303451.773272|e7110aed-0d08-4cb...|
|5a575a85329e1a000...| 1515674245.348099|25ca21fe-4dbb-446...|
+--------------------+------------------+--------------------+
```


Create a function my_lambda_questions 

```
def my_lambda_questions(x):
    raw_dict = json.loads(x.value)
    my_list = []
    my_count = 0
    for l in raw_dict["sequences"]["questions"]:
        my_count += 1
        my_dict = {"keen_id" : raw_dict["keen_id"], "my_count" : my_count, "id" : l["id"]}
        my_list.append(my_dict)
    return my_list
```



Create a new data frame my_questions using assessment_details_string.rdd.flatMap and create a temp table questions

```
my_questions = assessment_details_string.rdd.flatMap(my_lambda_questions).toDF()

my_questions.registerTempTable('questions')

```

Select my_count column from the temp table questions limit results to 10.


```
>>> spark.sql("select id, my_count from questions limit 10").show()
+--------------------+--------+
|                  id|my_count|
+--------------------+--------+
|7a2ed6d3-f492-49b...|       1|
|bbed4358-999d-446...|       2|
|e6ad8644-96b1-461...|       3|
|95194331-ac43-454...|       4|
|95194331-ac43-454...|       1|
|bbed4358-999d-446...|       2|
|e6ad8644-96b1-461...|       3|
|7a2ed6d3-f492-49b...|       4|
|b9ff2e88-cf9d-4bd...|       1|
|bec23e7b-4870-49f...|       2|
+--------------------+--------+
```

Join data from tables assessments and questions on the keen_id

```
>>> spark.sql("select q.keen_id, a.keen_timestamp, q.id from assessments a join questions q on a.keen_id = q.keen_id limit 10").show()
+--------------------+------------------+--------------------+
|             keen_id|    keen_timestamp|                  id|
+--------------------+------------------+--------------------+
|5a17a67efa1257000...|1511499390.3836269|803fc93f-7eb2-412...|
|5a17a67efa1257000...|1511499390.3836269|f3cb88cc-5b79-41b...|
|5a17a67efa1257000...|1511499390.3836269|32fe7d8d-6d89-4db...|
|5a17a67efa1257000...|1511499390.3836269|5c34cf19-8cfd-4f5...|
|5a26ee9cbf5ce1000...|1512500892.4166169|0603e6f4-c3f9-4c2...|
|5a26ee9cbf5ce1000...|1512500892.4166169|26a06b88-2758-45b...|
|5a26ee9cbf5ce1000...|1512500892.4166169|25b6effe-79b0-4c4...|
|5a26ee9cbf5ce1000...|1512500892.4166169|6de03a9b-2a78-46b...|
|5a26ee9cbf5ce1000...|1512500892.4166169|aaf39991-fa83-470...|
|5a26ee9cbf5ce1000...|1512500892.4166169|aab2e817-73dc-4ff...|
+--------------------+------------------+--------------------+

```

Select all the data from join between questions and assessments
```
>>> spark.sql("select * from assessments a join questions q on a.keen_id = q.keen_id limit 10").show()
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+--------------------+--------------------+--------+
|        base_exam_id|certification|           exam_name|   keen_created_at|             keen_id|    keen_timestamp|max_attempts|           sequences|          started_at|        user_exam_id|                  id|             keen_id|my_count|
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+--------------------+--------------------+--------+
|1a233da8-e6e5-48a...|        false|Intermediate Pyth...|1511499390.3836269|5a17a67efa1257000...|1511499390.3836269|         1.0|Map(questions -> ...|2017-11-24T04:54:...|ab96c540-1dbb-4c3...|803fc93f-7eb2-412...|5a17a67efa1257000...|       1|
|1a233da8-e6e5-48a...|        false|Intermediate Pyth...|1511499390.3836269|5a17a67efa1257000...|1511499390.3836269|         1.0|Map(questions -> ...|2017-11-24T04:54:...|ab96c540-1dbb-4c3...|f3cb88cc-5b79-41b...|5a17a67efa1257000...|       2|
|1a233da8-e6e5-48a...|        false|Intermediate Pyth...|1511499390.3836269|5a17a67efa1257000...|1511499390.3836269|         1.0|Map(questions -> ...|2017-11-24T04:54:...|ab96c540-1dbb-4c3...|32fe7d8d-6d89-4db...|5a17a67efa1257000...|       3|
|1a233da8-e6e5-48a...|        false|Intermediate Pyth...|1511499390.3836269|5a17a67efa1257000...|1511499390.3836269|         1.0|Map(questions -> ...|2017-11-24T04:54:...|ab96c540-1dbb-4c3...|5c34cf19-8cfd-4f5...|5a17a67efa1257000...|       4|
|b114e4a4-a192-4df...|        false|Learning to Progr...|1512500892.4166169|5a26ee9cbf5ce1000...|1512500892.4166169|         1.0|Map(questions -> ...|2017-12-05T19:07:...|eb6d3dcb-9f2c-40a...|0603e6f4-c3f9-4c2...|5a26ee9cbf5ce1000...|       1|
|b114e4a4-a192-4df...|        false|Learning to Progr...|1512500892.4166169|5a26ee9cbf5ce1000...|1512500892.4166169|         1.0|Map(questions -> ...|2017-12-05T19:07:...|eb6d3dcb-9f2c-40a...|26a06b88-2758-45b...|5a26ee9cbf5ce1000...|       2|
|b114e4a4-a192-4df...|        false|Learning to Progr...|1512500892.4166169|5a26ee9cbf5ce1000...|1512500892.4166169|         1.0|Map(questions -> ...|2017-12-05T19:07:...|eb6d3dcb-9f2c-40a...|25b6effe-79b0-4c4...|5a26ee9cbf5ce1000...|       3|
|b114e4a4-a192-4df...|        false|Learning to Progr...|1512500892.4166169|5a26ee9cbf5ce1000...|1512500892.4166169|         1.0|Map(questions -> ...|2017-12-05T19:07:...|eb6d3dcb-9f2c-40a...|6de03a9b-2a78-46b...|5a26ee9cbf5ce1000...|       4|
|b114e4a4-a192-4df...|        false|Learning to Progr...|1512500892.4166169|5a26ee9cbf5ce1000...|1512500892.4166169|         1.0|Map(questions -> ...|2017-12-05T19:07:...|eb6d3dcb-9f2c-40a...|aaf39991-fa83-470...|5a26ee9cbf5ce1000...|       5|
|b114e4a4-a192-4df...|        false|Learning to Progr...|1512500892.4166169|5a26ee9cbf5ce1000...|1512500892.4166169|         1.0|Map(questions -> ...|2017-12-05T19:07:...|eb6d3dcb-9f2c-40a...|aab2e817-73dc-4ff...|5a26ee9cbf5ce1000...|       6|
+--------------------+-------------+--------------------+------------------+--------------------+------------------+------------+--------------------+--------------------+--------------------+--------------------+--------------------+--------+

```



Commit the query results to the HDFS pas parquet files using the following command

```
commit_info = spark.sql("select count(base_exam_id) COUNT ,exam_name from assessments group by exam_name order by COUNT desc")
some_commit_info.write.parquet("/tmp/commit_info")
```

Login the cloudera container and check the files on the file system.
```
docker-compose exec cloudera hadoop fs -ls /tmp/
docker-compose exec cloudera hadoop fs -ls /tmp/commit_info

```

Display the schema for the data frame assessment_details_string using following command and the result is also presented

```
assessment_details_string.printSchema()
```

Check the count in the data frame using following command.

```
assessment_details_string.count()
```

```
3280

```

Exit pyspark using the well formed method:

```
exit()
```


## Tear down the cluster:

```
docker-compose down
```

All 5 containers should be shutdown with the following output.

```
Stopping assignment08bhuvneshsharma_kafka_1 ... done
Stopping assignment08bhuvneshsharma_cloudera_1 ... done
Stopping assignment08bhuvneshsharma_mids_1 ... done
Stopping assignment08bhuvneshsharma_zookeeper_1 ... done
Stopping assignment08bhuvneshsharma_spark_1 ... done
Removing assignment08bhuvneshsharma_kafka_1 ... done
Removing assignment08bhuvneshsharma_cloudera_1 ... done
Removing assignment08bhuvneshsharma_mids_1 ... done
Removing assignment08bhuvneshsharma_zookeeper_1 ... done
Removing assignment08bhuvneshsharma_spark_1 ... done
Removing network assignment08bhuvneshsharma_default

```

Verify that the cluster is properly down:


```
docker ps -a
```

## Learnings
Created an Architecture where we can have created set up where we have messaging system. We created docker containers of zookeeper , kafka and mids. We downloaded JSON file [ sample file ] using curl. We learnt how to configure docker-compose yml file to connect zookeeper and kafka and mids.
We created an multiple containers using the file system which is on the droplet given by berkeley mids program.We also learnt to create a messaging topic on the kafka system. We executed commands to read JSON file , break the records and publish those records to a kafka messaging system.
We also created a message subcribtion to read those messages real time. We also created a spark session using pyspark and subscribed to the messages. Within the pyspark utility we enabled python and accessed the RDD data frame and performed query. 

The advantages of spark is that we can perform extremely large parallel queries using RDD data set . 

The low latency and an easy-to-use event time support also apply to Kafka Streams. It is a rather focused library, and it’s very well-suited for certain types of tasks. That’s also why some of its design can be so optimized for how Kafka works. And if you need to do a simple Kafka topic-to-topic transformation, count elements by key, enrich a stream with data from another topic, or run an aggregation or only real-time processing — Kafka Streams is for you.

If event time is not relevant and latencies in the seconds range are acceptable, Spark is the first choice. It is stable and almost any type of system can be easily integrated. In addition it comes with every Hadoop distribution. Furthermore, the code used for batch applications can also be used for the streaming applications as the API is the same.

Spark SQL :  Spark SQL is a new module in Spark which integrates relational processing with Spark's functional programming API. It supports querying data either via SQL or via the Hive Query Language.

## Future
- Read individual elements of the individual records from Kafka messaging system and use it for analytics
- Real time enable publishing of records from a web application.
- Use spark system to run real time analytics on massively parallely system.
- Create Analytics application which can processes large amount user data.
- Integrate with HDFS and other database systems
- Create events based on JSON objects like 
	- Particular exams are completed . e.g "Learning Git"
	- if a student attempts a question more than particular number of times
- Create Analytics prediction on the probability that question can be correctly answered.
- Create Analytics solutions.
- Improve broker architecture.


Kafka brokers process records organized into topics. A topic is a category of records that share similar characteristics. For example, a topic might consist of instant messages from social media or navigation information for users on a web site. Each topic has a unique corresponding table in data storage.

A producer is an external process that sends records to a Kafka topic. A consumer is an external process that receives topic streams from a Kafka cluster.

![ALT TEXT](https://www.cloudera.com/documentation/kafka/latest/images/xtopic_producer_consumer.png.pagespeed.ic.gpLmxxi15Q.webp)

While these illustrations show single instances of the components of a Kafka implementation, Kafka brokers typically host multiple partitions and replicas, with any number of producers and consumers, up to the requirements and limits of the deployed system.
![ALT TEXT](https://www.cloudera.com/documentation/kafka/latest/images/many_to_many.png)

